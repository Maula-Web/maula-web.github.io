
class PronosticoManager {
    constructor() {
        this.members = [];
        this.jornadas = [];
        this.pronosticos = [];

        this.currentMemberId = null;
        this.currentJornadaId = null;

        // Correction Mode State
        this.correctionMode = false;
        this.pendingSaveData = null; // To store data while audit modal is open

        this.cacheDOM(); // Capture DOM elements immediately
        this.init();
    }




    cacheDOM() {
        this.selMember = document.getElementById('sel-member');
        this.selJornada = document.getElementById('sel-jornada');
        this.activeSelectionInfo = document.getElementById('active-selection-info');
        this.selMethod = document.getElementById('sel-method');
        this.container = document.getElementById('forecast-container');
        this.statusMsg = document.getElementById('status-message');
        this.costInfo = document.getElementById('cost-info');
        this.deadlineInfo = document.getElementById('deadline-info');
        this.btnSave = document.getElementById('btn-save');

        // Doubles DOM
        this.doublesSection = document.getElementById('doubles-section');
        this.doublesContainer = document.getElementById('doubles-container');
        this.doublesCounter = document.getElementById('doubles-counter');
        this.btnSaveDoubles = document.getElementById('btn-save-doubles');
        this.btnCopyForecast = document.getElementById('btn-copy-forecast');
        this.doublesStatus = document.getElementById('doubles-status');
        this.doublesInfoHeader = document.getElementById('doubles-status-card');

        // Summary Table Elements
        this.summaryTable = document.getElementById('forecast-summary-table');
        this.summaryContainer = document.getElementById('summary-container');

        // Correction Mode Elements
        this.chkCorrection = document.getElementById('chk-correction-mode');
        this.lblCorrection = document.getElementById('lbl-correction');

        // Audit Modal Elements
        this.auditModal = document.getElementById('audit-modal-overlay');
        this.auditReason = document.getElementById('audit-reason');
        this.auditLateCheck = document.getElementById('audit-late-penalty');
        this.btnConfirmAudit = document.getElementById('btn-confirm-audit');
        this.btnCancelAudit = document.getElementById('btn-cancel-audit');

        // Collective View Modal
        this.btnViewJornada = document.getElementById('btn-view-jornada');
        this.viewJornadaModal = document.getElementById('view-jornada-modal');
        this.viewJornadaTitle = document.getElementById('view-jornada-title');
        this.viewJornadaContent = document.getElementById('view-jornada-content');
        this.btnCloseViewJornada = document.getElementById('btnCloseViewJornada');
        this.btnCloseMobileFloat = document.getElementById('btn-close-mobilefloat');
        this.selModalJornada = document.getElementById('sel-modal-jornada');
        this.btnPrevJornada = document.getElementById('btn-prev-jornada');
        this.btnNextJornada = document.getElementById('btn-next-jornada');
        this.btnLoadForecast = document.getElementById('btn-load-forecast');
        this.btnClearForecast = document.getElementById('btn-clear-forecast');

        // Help Doubles Modal
        this.btnHelpDoubles = document.getElementById('btn-help-doubles');
        this.helpModal = document.getElementById('help-doubles-modal');
        this.btnCloseHelp = document.getElementById('btnCloseHelpDoubles');
        this.mobileTabs = document.getElementById('mobile-help-tabs');
        this.btnShowPhysical = document.getElementById('btn-show-physical');
        this.btnShowDigital = document.getElementById('btn-show-digital');
        this.physicalSection = document.getElementById('help-physical-section');
        this.digitalSection = document.getElementById('help-digital-section');
        this.marksPhysical = document.getElementById('marks-physical');
        this.marksDigital = document.getElementById('marks-digital');


        this.btnToggleSummary = document.getElementById('btn-toggle-summary');
        if (this.btnToggleSummary) {
            this.btnToggleSummary.addEventListener('click', () => {
                const isHidden = this.summaryContainer.style.display === 'none';
                this.summaryContainer.style.display = isHidden ? 'block' : 'none';
            });
        }

        // Table Delegation for clicking cells
        if (this.summaryTable) {
            this.summaryTable.addEventListener('click', (e) => {
                const cell = e.target.closest('td.summary-cell');
                if (cell) {
                    const jId = cell.dataset.jid;
                    const mId = cell.dataset.mid;
                    if (jId) {
                        if (mId) {
                            this.selectAndLoad(jId, mId);
                        } else if (cell.dataset.isdoubles) {
                            const parsedJId = parseInt(jId) || jId;
                            const jornada = this.jornadas.find(j => j.id == parsedJId);
                            let targetMemberId = null;
                            if (jornada && typeof this.checkEligibility === 'function') {
                                for (const m of this.members) {
                                    const elig = this.checkEligibility(jornada.number, m.id);
                                    if (elig && elig.eligible) {
                                        targetMemberId = m.id;
                                        break;
                                    }
                                }
                            }
                            if (!targetMemberId && this.members && this.members.length > 0) {
                                targetMemberId = this.members[0].id;
                            }
                            if (targetMemberId) {
                                this.selectAndLoad(parsedJId, targetMemberId);
                            }
                        }
                    }
                }
            });
        }

        // Correction Toggle
        if (this.chkCorrection) {
            this.chkCorrection.addEventListener('change', (e) => {
                this.correctionMode = e.target.checked;
                this.updateCorrectionUI();
                this.loadForecast();
            });
        }

        // Audit Modal Actions
        if (this.btnConfirmAudit) this.btnConfirmAudit.addEventListener('click', () => this.executeAuditSave());
        if (this.btnCancelAudit) this.btnCancelAudit.addEventListener('click', () => {
            this.auditModal.classList.remove('active');
            document.body.style.overflow = '';
            this.pendingSaveData = null;
        });

        // Collective View Events
        if (this.btnViewJornada) {
            this.btnViewJornada.addEventListener('click', (e) => {
                e.preventDefault();
                this.showJornadaForecasts();
            });
        }
        if (this.btnCloseViewJornada) {
            this.btnCloseViewJornada.addEventListener('click', () => {
                this.viewJornadaModal.style.display = 'none';
            });
        }
        if (this.btnCloseMobileFloat) {
            this.btnCloseMobileFloat.addEventListener('click', () => {
                this.viewJornadaModal.style.display = 'none';
            });
        }
        if (this.selModalJornada) {
            this.selModalJornada.addEventListener('change', (e) => {
                this.showJornadaForecasts(e.target.value);
            });
        }

        // Navigation Arrow Events
        if (this.btnPrevJornada) {
            this.btnPrevJornada.addEventListener('click', () => {
                this.navigateJornada('prev');
            });
        }
        if (this.btnNextJornada) {
            this.btnNextJornada.addEventListener('click', () => {
                this.navigateJornada('next');
            });
        }


        if (this.btnSaveDoubles) this.btnSaveDoubles.addEventListener('click', () => this.saveDoubles());
        if (this.btnCopyForecast) this.btnCopyForecast.addEventListener('click', () => this.handleCopyForecast());

        if (this.btnHelpDoubles) this.btnHelpDoubles.addEventListener('click', () => this.showHelpDoubles());
        if (this.btnCloseHelp) this.btnCloseHelp.addEventListener('click', () => {
            this.helpModal.style.display = 'none';
            this.helpModal.classList.remove('active');
        });
        if (this.btnShowPhysical) this.btnShowPhysical.addEventListener('click', () => this.switchHelpView('physical'));
        if (this.btnShowDigital) this.btnShowDigital.addEventListener('click', () => this.switchHelpView('digital'));
    }

    async init() {
        if (window.DataService) await window.DataService.init();

        const data = await window.DataService.loadSeasonData();
        this.members = data.members;
        this.jornadas = data.jornadas;
        this.pronosticos = data.pronosticos;
        this.pronosticosExtra = data.pronosticosExtra;

        if (window.DiceService) {
            try {
                await window.DiceService.checkAndApplyDice(this.members, this.jornadas, this.pronosticos);
            } catch (errDice) {
                console.error("Error ejecutando DiceService:", errDice);
            }
        }

        this.populateDropdowns();
        this.renderSummaryTable();
        this.bindEvents();
        this.updateActiveSelectionUI();
    }

    // ... (populateDropdowns, updateCorrectionUI, etc remains same) ...




    updateCorrectionUI() {
        const slider = this.chkCorrection.nextElementSibling;
        if (this.correctionMode) {
            slider.style.backgroundColor = 'var(--primary-orange)';
            this.lblCorrection.style.color = 'var(--primary-orange)';
            this.lblCorrection.textContent = "MODO CORRECCIÓN ACTIVO";
        } else {
            slider.style.backgroundColor = '#ccc';
            this.lblCorrection.style.color = 'var(--text-secondary)';
            this.lblCorrection.textContent = "Modo Corrección";
        }
    }

    bindEvents() {
        if (this.selMember) {
            this.selMember.addEventListener('change', (e) => {
                this.currentMemberId = e.target.value;
                this.loadForecast();
            });
        }

        if (this.selJornada) {
            this.selJornada.addEventListener('change', (e) => {
                this.currentJornadaId = e.target.value;
                this.loadForecast();
            });
        }

        this.btnSave.addEventListener('click', () => this.saveForecast());
        if (this.btnClearForecast) {
            this.btnClearForecast.addEventListener('click', () => this.handleClearForecast());
        }
    }

    selectAndLoad(jId, mId) {
        const parsedJId = parseInt(jId) || jId;
        const parsedMId = parseInt(mId) || mId;

        this.currentJornadaId = parsedJId;
        this.currentMemberId = parsedMId;

        // Try to sync Dropdowns if present
        if (this.selJornada) {
            const opt = this.selJornada.querySelector(`option[value="${parsedJId}"]`);
            if (opt) {
                this.selJornada.value = parsedJId;
            } else {
                this.selJornada.value = '';
            }
        }

        if (this.selMember) {
            const opt = this.selMember.querySelector(`option[value="${parsedMId}"]`);
            if (opt) this.selMember.value = parsedMId;
        }

        // Highlight active cell in summary table
        if (this.summaryTable) {
            this.summaryTable.querySelectorAll('.summary-cell.active-cell').forEach(c => c.classList.remove('active-cell'));
            const activeCell = this.summaryTable.querySelector(`td.summary-cell[data-jid="${parsedJId}"][data-mid="${parsedMId}"]`);
            if (activeCell) {
                activeCell.classList.add('active-cell');
            }
        }

        this.loadForecast();

        // Scroll to top to see the forecast
        window.scrollTo({ top: 0, behavior: 'smooth' });

        // Highlight logic
        this.container.style.transition = 'background-color 0.3s';
        this.container.style.backgroundColor = '#fff8e1'; // Highlight flash
        setTimeout(() => {
            this.container.style.backgroundColor = 'transparent';
        }, 500);
    }

    updateActiveSelectionUI() {
        if (!this.activeSelectionInfo) return;

        if (!this.currentMemberId || !this.currentJornadaId) {
            this.activeSelectionInfo.innerHTML = `
                <div style="display: flex; align-items: center; gap: 8px; color: var(--text-secondary); font-size: 0.95rem; flex-wrap: wrap;">
                    <span style="font-size: 1.2rem;">👇</span>
                    <span>Haz clic en una casilla del <strong>Resumen de Pronósticos</strong> inferior para ver o rellenar la quiniela.</span>
                </div>
            `;
            return;
        }

        const member = this.members.find(m => String(m.id) === String(this.currentMemberId));
        const jornada = this.jornadas.find(j => String(j.id) === String(this.currentJornadaId));
        const existing = this.pronosticos.find(p => (String(p.jId) === String(this.currentJornadaId) || String(p.jornadaId) === String(this.currentJornadaId)) && (String(p.mId) === String(this.currentMemberId) || String(p.memberId) === String(this.currentMemberId)));

        const memberName = member ? AppUtils.getMemberName(member) : `Socio #${this.currentMemberId}`;
        const jornadaText = jornada ? `Jornada ${jornada.number} (${jornada.date})` : `Jornada #${this.currentJornadaId}`;
        const diceBadgeHtml = (existing && existing.isDice) ? `
            <span style="background: rgba(103, 58, 183, 0.12); color: #673ab7; padding: 5px 12px; border-radius: 20px; font-weight: bold; font-size: 0.95rem; border: 1px solid rgba(103, 58, 183, 0.3); display: inline-flex; align-items: center; gap: 6px;" title="Rellenado automáticamente por El Dado de Quinielas">
                🎲 <span>Relleno con Dado</span>
            </span>
        ` : '';

        this.activeSelectionInfo.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                <span style="background: var(--primary-color, #1976d2); color: white; padding: 5px 12px; border-radius: 20px; font-weight: bold; font-size: 0.95rem; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    👤 <span>${memberName}</span>
                </span>
                <span style="background: rgba(25, 118, 210, 0.1); color: var(--primary-color, #1976d2); padding: 5px 12px; border-radius: 20px; font-weight: bold; font-size: 0.95rem; border: 1px solid rgba(25, 118, 210, 0.25); display: inline-flex; align-items: center; gap: 6px;">
                    📅 <span>${jornadaText}</span>
                </span>
                ${diceBadgeHtml}
                <button type="button" id="btn-close-forecast" style="background: rgba(244, 67, 54, 0.1); border: 1px solid rgba(244, 67, 54, 0.3); border-radius: 20px; padding: 5px 12px; font-size: 0.85rem; color: #d32f2f; cursor: pointer; display: inline-flex; align-items: center; gap: 4px; font-weight: 600; transition: all 0.2s;" title="Cerrar pronóstico">
                    ✖ Cerrar
                </button>
            </div>
        `;

        const btnClose = this.activeSelectionInfo.querySelector('#btn-close-forecast');
        if (btnClose) {
            btnClose.addEventListener('click', () => this.closeForecast());
        }
    }

    closeForecast() {
        this.currentMemberId = null;
        this.currentJornadaId = null;
        this.container.innerHTML = '';
        this.container.classList.add('hidden');
        if (this.doublesSection) this.doublesSection.classList.add('hidden');
        if (this.doublesInfoHeader) this.doublesInfoHeader.style.display = 'none';
        this.btnSave.style.display = 'none';
        if (this.btnClearForecast) this.btnClearForecast.style.display = 'none';
        this.statusMsg.textContent = '';
        this.deadlineInfo.textContent = '';
        if (this.costInfo) this.costInfo.textContent = '';
        if (this.summaryTable) {
            this.summaryTable.querySelectorAll('.summary-cell.active-cell').forEach(c => c.classList.remove('active-cell'));
        }
        this.updateActiveSelectionUI();
    }

    populateDropdowns() {
        if (this.selMember) {
            const sortedMembers = [...this.members].sort((a, b) => parseInt(a.id) - parseInt(b.id));

            sortedMembers.forEach(m => {
                const opt = document.createElement('option');
                opt.value = m.id;
                opt.textContent = AppUtils.getMemberName(m);
                this.selMember.appendChild(opt);
            });
        }

        if (this.selJornada) {
            // Filter journeys that have matches informed (at least one team name set)
            const informedJornadas = this.jornadas.filter(j => {
                // Must be active AND have matches with at least one home team name
                return j.active && j.matches && j.matches.some(m => m.home && m.home.trim() !== '');
            });

            // Sort by number descending (most recent first)
            const sortedJornadas = informedJornadas.sort((a, b) => b.number - a.number);

            sortedJornadas.forEach(j => {
                const opt = document.createElement('option');
                opt.value = j.id;
                opt.textContent = `Jornada ${j.number} - ${j.date}`;
                this.selJornada.appendChild(opt);
            });
        }
    }

    loadForecast() {
        this.container.innerHTML = '';
        this.container.classList.add('hidden');
        if (this.doublesSection) this.doublesSection.classList.add('hidden');
        if (this.doublesInfoHeader) this.doublesInfoHeader.style.display = 'none';
        this.btnSave.style.display = 'none';
        if (this.btnClearForecast) this.btnClearForecast.style.display = 'none';
        this.statusMsg.textContent = '';
        this.deadlineInfo.textContent = '';
        this._fullForecastNotified = false;

        // Ensure IDs are synced with selects if they exist and have a value
        if (this.selMember && this.selMember.value) this.currentMemberId = this.selMember.value;
        if (this.selJornada && this.selJornada.value) this.currentJornadaId = this.selJornada.value;

        if (!this.currentMemberId || !this.currentJornadaId) {
            this.updateActiveSelectionUI();
            return;
        }

        const jornada = this.jornadas.find(j => j.id == this.currentJornadaId);
        if (!jornada) {
            this.updateActiveSelectionUI();
            return;
        }

        this.updateActiveSelectionUI();

        const { isLockedRef, isFinished, hasStarted } = this.isJornadaLocked(jornada);

        // CORRECTION OVERRIDE: If Mode is Active, ignore lock
        const isLocked = this.correctionMode ? false : isLockedRef;

        const deadline = this.calculateDeadline(jornada.date);
        const now = new Date();
        const isLate = deadline ? (now > deadline) : false;

        if (deadline) {
            const dStr = deadline.toLocaleDateString() + ' ' + deadline.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            this.deadlineInfo.innerHTML = isLate ?
                `<span style="color:var(--danger)">Plazo expirado (${dStr})</span>` :
                `<span style="color:var(--primary-green)">Cierre: ${dStr}</span>`;
        }

        const existing = this.pronosticos.find(p => (p.jId == this.currentJornadaId || p.jornadaId == this.currentJornadaId) && (p.mId == this.currentMemberId || p.memberId == this.currentMemberId));

        if (isLockedRef) {
            if (this.correctionMode) {
                const label = isFinished ? 'JORNADA CERRADA' : 'JORNADA EN JUEGO';
                this.statusMsg.innerHTML = `<span class="badge-late" style="border:2px solid var(--primary-orange); color:var(--primary-orange);">🛠️ EDITANDO ${label} (Modo Corrección)</span>`;
                this.container.style.border = "2px dashed var(--primary-orange)";
            } else {
                const hasExistingForecast = existing && Array.isArray(existing.selection) && existing.selection.some(s => s && String(s).trim() !== '' && String(s).trim() !== '-');
                if (!hasExistingForecast && (hasStarted || isFinished)) {
                    this.statusMsg.innerHTML = `<span class="badge-locked" style="background:#d32f2f; color:white; border: 1.5px solid #b71c1c; font-weight: bold; padding: 6px 14px; border-radius: 12px; display: inline-flex; align-items: center; gap: 6px;">🔒 JORNADA EN JUEGO (HAY RESULTADOS) - NO SE ADMITEN PRONÓSTICOS</span>`;
                } else {
                    const label = isFinished ? 'JORNADA FINALIZADA' : 'JORNADA EN JUEGO';
                    this.statusMsg.innerHTML = `<span class="badge-locked">🔒 ${label} - NO SE ADMITEN CAMBIOS</span>`;
                }
                this.container.style.border = "none";
            }
        } else {
            this.container.style.border = "none";
            // Si la jornada no está bloqueada, el aviso FUERA DE PLAZO no se muestra al abrir
            // (a menos que ya se hubiera guardado con retraso anteriormente de forma informativa).
            if (existing && existing.isDice) {
                this.statusMsg.innerHTML = '<span class="badge-dice" style="background: rgba(103, 58, 183, 0.12); color: #673ab7; border: 1.5px solid #673ab7; font-weight: bold; padding: 4px 12px; border-radius: 12px; display: inline-flex; align-items: center; gap: 6px;">🎲 PRONÓSTICO AUTORRELLENADO CON DADO</span>';
            } else if (existing && existing.late) {
                this.statusMsg.innerHTML = '<span class="badge-late">⚠️ PRONÓSTICO ENVIADO CON RETRASO</span>';
            } else {
                this.statusMsg.innerHTML = '';
            }
        }

        // Update Method Dropdown
        if (this.selMethod) {
            this.selMethod.value = (existing && existing.isReduced) ? 'reducido' : 'directo';
        }

        const currentSelections = existing ? existing.selection : Array(15).fill(null);
        // Only consider the first 14 signs for the "completed" notification
        if (currentSelections.slice(0, 14).filter(s => s !== null).length === 14) {
            this._fullForecastNotified = true;
        }

        // Fetch other members' forecasts for this jornada
        const othersForecasts = this.pronosticos.filter(p =>
            (p.jId == this.currentJornadaId || p.jornadaId == this.currentJornadaId) &&
            (p.mId != this.currentMemberId && p.memberId != this.currentMemberId)
        );

        jornada.matches.forEach((match, idx) => {
            const displayIdx = idx === 14 ? 'P15' : idx + 1;
            const row = document.createElement('div');
            row.className = 'pronostico-row';

            let disabledStr = isLocked ? 'style="pointer-events:none; opacity:0.6;"' : '';
            if (disabledStr === '' && this.correctionMode && isLockedRef) {
                // Visual cue that elements are unlocked specially
            }

            // Pleno Restriction
            let isPigMatch = false;
            if (idx === 14) {
                isPigMatch = typeof AppUtils !== 'undefined' && AppUtils.isPigMatch(match.home, match.away);
                if (!isPigMatch) {
                    disabledStr = 'style="pointer-events:none; opacity:0.3; background:transparent;" title="Pleno deshabilitado"';
                }
            }

            const val = currentSelections[idx];
            const homeLogo = AppUtils.getTeamLogo(match.home);
            const awayLogo = AppUtils.getTeamLogo(match.away);

            // Generate "Others" HTML - COMPACT VERSION (No initials, just boxes)
            let othersHtml = othersForecasts.map(of => {
                const member = this.members.find(m => m.id === of.mId || m.id === of.memberId);
                if (!member) return '';
                const sign = of.selection[idx];
                if (!sign) return '';

                const displayName = AppUtils.getMemberName(member);
                return `
                    <div class="others-item" title="${displayName}: ${sign}" data-sign="${sign}">
                         <span>${sign}</span>
                    </div>
                `;
            }).join('');

            // Calculate initial percentages
            const allSigns = othersForecasts.map(of => of.selection[idx]).filter(s => s);
            if (val) allSigns.push(val);
            const total = allSigns.length;
            let p1 = 0, pX = 0, p2 = 0;
            if (total > 0) {
                p1 = (allSigns.filter(s => s === '1').length / total * 100).toFixed(0);
                pX = (allSigns.filter(s => s === 'X').length / total * 100).toFixed(0);
                p2 = (allSigns.filter(s => s === '2').length / total * 100).toFixed(0);
            }

            row.innerHTML = `
                <div class="p-match-info">
                    <span class="p-match-num">${displayIdx}${isPigMatch ? ' 🐷' : ''}</span>
                    <div class="match-team home-team">
                        <span class="team-name">${match.home}</span>
                        <img src="${homeLogo}" class="team-logo" onerror="this.style.display='none'">
                    </div>
                    <span class="match-vs-separator">-</span>
                    <div class="match-team away-team">
                        <img src="${awayLogo}" class="team-logo" onerror="this.style.display='none'">
                        <span class="team-name">${match.away}</span>
                    </div>
                    ${isPigMatch ? '<span style="font-size:0.75rem; background:#ffecb3; color:#e65100; border-radius:4px; padding:2px 6px; font-weight:bold; margin-left:6px;" title="Partido de Interés General">🐷 PIG</span>' : ''}
                </div>

                <div class="p-others">
                    ${othersHtml || '<span class="no-others">-</span>'}
                </div>

                <div class="p-options" ${disabledStr} data-idx="${idx}">
                    <div class="chk-option ${val === '1' ? 'selected' : ''}" onclick="window.app.selectOption(this, '1')">1</div>
                    <div class="chk-option ${val === 'X' ? 'selected' : ''}" onclick="window.app.selectOption(this, 'X')">X</div>
                    <div class="chk-option ${val === '2' ? 'selected' : ''}" onclick="window.app.selectOption(this, '2')">2</div>
                </div>

                <div id="consensus-${idx}" class="p-percentages">
                    <div class="perc-row perc-1"><span>1:</span> <b>${p1}%</b></div>
                    <div class="perc-row perc-X"><span>X:</span> <b>${pX}%</b></div>
                    <div class="perc-row perc-2"><span>2:</span> <b>${p2}%</b></div>
                </div>
            `;
            this.container.appendChild(row);

            // Add Block Dividers: 4, 4, 3, 3 + Pleno al 15
            // 4-5 (idx 3), 8-9 (idx 7), 11-12 (idx 10), 14-15 (idx 13)
            if ([3, 7, 10, 13].includes(idx)) {
                const divider = document.createElement('div');
                if (idx === 13) {
                    divider.className = "p-divider p-divider-p15";
                    divider.innerHTML = `<span class="boleto-block-label">PLENO AL 15</span>`;
                } else {
                    divider.className = "p-divider p-divider-block";
                }
                this.container.appendChild(divider);
            }
        });

        this.container.classList.remove('hidden');
        if (!isLocked) {
            this.btnSave.style.display = 'block';
            if (this.btnClearForecast) this.btnClearForecast.style.display = 'inline-block';

            if (isLockedRef && this.correctionMode) {
                this.btnSave.innerHTML = "🛠️ Guardar Corrección";
                this.btnSave.style.backgroundColor = "var(--primary-orange)";
            } else {
                this.btnSave.innerHTML = "💾 Guardar Pronóstico";
                this.btnSave.style.backgroundColor = "var(--primary-green)";
            }
        } else {
            this.btnSave.style.display = 'none';
        }

        // DOUBLES LOGIC
        if (!isLocked || this.correctionMode) {
            if (typeof this.checkEligibility === 'function') {
                const eligibility = this.checkEligibility(jornada.number, this.currentMemberId);
                if (eligibility && eligibility.eligible) {
                    if (this.renderDoublesForm) this.renderDoublesForm(jornada, isLocked);
                    if (this.doublesSection) this.doublesSection.classList.remove('hidden');
                    if (this.doublesInfoHeader) this.doublesInfoHeader.style.display = 'flex';
                }
            }
        }

        // Initial cost update
        this.updateCost();
    }

    selectOption(el, val) {
        // Bloqueo estricto: si la jornada está bloqueada (en juego con resultados o finalizada) sin Modo Corrección, no permitir selección
        const jornada = this.jornadas.find(j => j.id == this.currentJornadaId);
        if (jornada) {
            const { isLockedRef } = this.isJornadaLocked(jornada);
            if (isLockedRef && !this.correctionMode) {
                return;
            }
        }

        const parent = el.parentElement;
        const idx = parseInt(parent.dataset.idx);
        const isAlreadySelected = el.classList.contains('selected');

        // Toggle Logic: Unselect if clicked again
        parent.querySelectorAll('.chk-option').forEach(c => c.classList.remove('selected'));

        let finalVal = val;
        if (isAlreadySelected) {
            finalVal = null;
        } else {
            el.classList.add('selected');
        }

        // Update consensus in real-time
        this.updateRowConsensus(idx, finalVal);

        // Update cost/penalty
        this.updateCost();

        // Si estamos fuera de plazo y se cambia el pronóstico:
        if (jornada) {
            const deadline = this.calculateDeadline(jornada.date);
            const isLate = deadline ? (new Date() > deadline) : false;
            const { isLockedRef } = this.isJornadaLocked(jornada);
            if (isLate && (!isLockedRef || this.correctionMode)) {
                this.statusMsg.innerHTML = '<span class="badge-late">⚠️ FUERA DE PLAZO - SE MARCARÁ COMO RETRASADO</span>';
            }
        }

        // Trigger Auto-save
        this.autoSave();
    }

    updateRowConsensus(idx, myVal) {
        const othersForecasts = this.pronosticos.filter(p =>
            (p.jId == this.currentJornadaId || p.jornadaId == this.currentJornadaId) &&
            (p.mId != this.currentMemberId && p.memberId != this.currentMemberId)
        );

        const signs = othersForecasts.map(of => of.selection[idx]).filter(s => s);
        if (myVal) signs.push(myVal);
        const total = signs.length;
        if (total === 0) return;

        const s1 = (signs.filter(s => s === '1').length / total * 100).toFixed(0);
        const sX = (signs.filter(s => s === 'X').length / total * 100).toFixed(0);
        const s2 = (signs.filter(s => s === '2').length / total * 100).toFixed(0);

        const consensusBox = document.getElementById(`consensus-${idx}`);
        if (consensusBox) {
            consensusBox.innerHTML = `
                <div class="perc-row perc-1"><span>1:</span> <b>${s1}%</b></div>
                <div class="perc-row perc-X"><span>X:</span> <b>${sX}%</b></div>
                <div class="perc-row perc-2"><span>2:</span> <b>${s2}%</b></div>
            `;
        }
    }

    updateCost() {
        if (!this.costInfo) return;

        // Count '1's in the first 14 matches
        let onesCount = 0;
        const rows = this.container.querySelectorAll('.p-options');
        rows.forEach(row => {
            const idx = parseInt(row.dataset.idx);
            if (idx === 14) return; // Skip P15
            const selected = row.querySelector('.chk-option.selected');
            if (selected && selected.textContent === '1') {
                onesCount++;
            }
        });

        let penalty = 0;
        let color = "var(--primary-green)";
        let msg = "";

        if (onesCount === 10) penalty = 0.10;
        else if (onesCount === 11) penalty = 0.20;
        else if (onesCount === 12) penalty = 0.30;
        else if (onesCount === 13) penalty = 0.50;
        else if (onesCount >= 14) penalty = 1.00;

        if (penalty > 0) {
            msg = `💰 Penalización: +${penalty.toFixed(2)} € (${onesCount} unos en 14 signos)`;
            color = "#ef6c00"; // Orange
        } else {
            msg = `✅ Sin penalización (${onesCount} unos)`;
            color = "var(--primary-green)";
        }

        this.costInfo.innerHTML = `<span style="font-weight:bold; color:${color}; padding: 5px 10px; border-radius: 4px; background: rgba(0,0,0,0.05);">${msg}</span>`;
    }

    async autoSave() {
        if (!this.currentMemberId || !this.currentJornadaId) return;

        // Use a small timeout to debounce multiple clicks and avoid saturation
        if (this._autoSaveTimer) clearTimeout(this._autoSaveTimer);

        this._autoSaveTimer = setTimeout(async () => {
            try {
                const rows = this.container.querySelectorAll('.p-options');
                const selection = [];
                rows.forEach((r) => {
                    const sel = r.querySelector('.selected');
                    selection.push(sel ? sel.textContent : null);
                });

                const jornada = this.jornadas.find(j => j.id == this.currentJornadaId);
                if (!jornada) return;

                const { isLockedRef } = this.isJornadaLocked(jornada);
                // Locked check: don't auto-save if locked (in correctionMode, require manual save/audit modal)
                if (isLockedRef) return;

                const deadline = this.calculateDeadline(jornada.date);
                const now = new Date();
                const isLate = deadline ? (now > deadline) : false;

                const isReduced = this.selMethod && this.selMethod.value === 'reducido';
                const id = `${this.currentJornadaId}_${this.currentMemberId}`;

                const record = {
                    id: id,
                    jId: this.currentJornadaId,
                    mId: this.currentMemberId,
                    selection: selection,
                    isReduced: isReduced,
                    timestamp: new Date().toISOString(),
                    late: isLate
                };

                await window.DataService.save('pronosticos', record);

                // Sync local state
                const idx = this.pronosticos.findIndex(p => p.id == record.id);
                if (idx > -1) {
                    this.pronosticos[idx] = { ...this.pronosticos[idx], ...record };
                } else {
                    this.pronosticos.push(record);
                }

                // Update summary table in background
                this.renderSummaryTable();
                console.log("Auto-save silenciado OK (Late:", isLate, ")");

                // NEW: Alert if completed (checking first 14 signs)
                const isFull14 = selection.slice(0, 14).filter(s => s !== null).length === 14;
                if (isFull14 && !this._fullForecastNotified) {
                    this._fullForecastNotified = true;
                    if (typeof FRASES_MAULA !== 'undefined' && FRASES_MAULA.length > 0) {
                        const randomPhrase = FRASES_MAULA[Math.floor(Math.random() * FRASES_MAULA.length)];
                        setTimeout(() => {
                            alert('¡PRONÓSTICO COMPLETADO Y GUARDADO!\n\n' + randomPhrase);
                        }, 50);
                    }
                }

            } catch (e) {
                console.error("Auto-save error:", e);
            }
        }, 800);
    }

    handleClearForecast() {
        const jornada = this.jornadas.find(j => j.id == this.currentJornadaId);
        if (jornada) {
            const { isLockedRef } = this.isJornadaLocked(jornada);
            if (isLockedRef && !this.correctionMode) {
                alert("No se puede borrar el pronóstico porque la jornada está bloqueada.");
                return;
            }
        }

        if (!confirm('¿Estás seguro de que quieres borrar todos los signos de este pronóstico?')) return;

        const options = this.container.querySelectorAll('.chk-option.selected');
        options.forEach(opt => opt.classList.remove('selected'));

        // Update cost/penalty display after clearing
        this.updateCost();

        // Trigger save immediately to persist the clearing
        this.saveForecast();
    }

    showHelpDoubles() {
        if (!this.helpModal) return;

        // Force visibility and override any CSS opacity 0
        this.helpModal.style.display = 'flex';
        this.helpModal.style.opacity = '1';
        this.helpModal.style.visibility = 'visible';
        this.helpModal.style.zIndex = '2000000';
        this.helpModal.classList.add('active');

        this.renderHelpMarks();

        const isMobile = window.innerWidth <= 768;
        if (isMobile) {
            if (this.mobileTabs) this.mobileTabs.style.display = 'flex';
            this.switchHelpView('physical'); // Default to physical on mobile
        } else {
            if (this.mobileTabs) this.mobileTabs.style.display = 'none';
            // On desktop show both side by side
            if (this.physicalSection) this.physicalSection.style.display = 'block';
            if (this.digitalSection) this.digitalSection.style.display = 'block';
        }
    }

    switchHelpView(view) {
        if (!this.physicalSection || !this.digitalSection) return;

        if (view === 'physical') {
            this.physicalSection.style.display = 'block';
            this.digitalSection.style.display = 'none';
            this.btnShowPhysical.style.background = '#607d8b';
            this.btnShowPhysical.style.color = 'white';
            this.btnShowDigital.style.background = '#cfd8dc';
            this.btnShowDigital.style.color = '#333';
        } else {
            this.physicalSection.style.display = 'none';
            this.digitalSection.style.display = 'block';
            this.btnShowPhysical.style.background = '#cfd8dc';
            this.btnShowPhysical.style.color = '#333';
            this.btnShowDigital.style.background = '#607d8b';
            this.btnShowDigital.style.color = 'white';
        }
    }

    renderHelpMarks() {
        // Deactivated for now as per user request
        if (!this.marksPhysical || !this.marksDigital) return;
        this.marksPhysical.innerHTML = '';
        this.marksDigital.innerHTML = '';
        return;
        // We look for ANY member's extra forecast that has valid signs, since normally only one is filled.
        const pExtra = (this.pronosticosExtra || []).find(p =>
            (String(p.jId || p.jornadaId) === String(this.currentJornadaId)) &&
            (p.selection && p.selection.some(s => s && s.trim() !== '' && s !== '-'))
        );

        if (!pExtra || !pExtra.selection) {
            const msg = '<div style="position:absolute; top:40%; left:50%; transform:translate(-50%,-50%); color:white; background:rgba(0,0,0,0.85); padding:30px; border-radius:15px; font-size:1.2rem; text-align:center; width:80%; box-shadow:0 15px 40px rgba(0,0,0,0.5); z-index:1000; border:2px solid #00e5ff;">⚠️ No se han encontrado dobles guardados para la Jornada ' + this.currentJornadaId + '.<br><br><span style="font-size:0.9rem; opacity:0.8;">Asegúrate de que alguien haya rellenado y guardado la quiniela de dobles primero.</span></div>';
            this.marksPhysical.innerHTML = msg;
            this.marksDigital.innerHTML = msg;
            return;
        }

        const sel = pExtra.selection;
        let doublesCount = 0;
        let doubleIndices = [];

        // ---------------------------------------------------------
        // 1. PHYSICAL GRID (Basado en Excel A1:AG33 = 33x33 celdas)
        // ---------------------------------------------------------
        const gC = 33;
        const gP = (c) => ((c - 0.5) / gC) * 100;

        const phys = {
            c1: gP(10), cX: gP(12), c2: gP(14),
            cP: gP(16), cT: gP(20),
            p15Cols: { '0': gP(2), '1': gP(4), '2': gP(6), 'M': gP(8) },
            r15E1: gP(28), r15E2: gP(29)
        };

        sel.forEach((sign, idx) => {
            if (idx === 14) return;
            const rE = 2 + (idx * 2);
            const y = gP(rE);
            if (sign.includes('1')) this.drawX(this.marksPhysical, phys.c1, y);
            if (sign.includes('X')) this.drawX(this.marksPhysical, phys.cX, y);
            if (sign.includes('2')) this.drawX(this.marksPhysical, phys.c2, y);
            if (sign.length === 2) {
                doublesCount++;
                doubleIndices.push(idx + 1);
            }
        });

        const p15Val = sel[14] || '';
        if (p15Val.includes('-')) {
            const [h, a] = p15Val.split('-');
            if (phys.p15Cols[h]) this.drawX(this.marksPhysical, phys.p15Cols[h], phys.r15E1);
            if (phys.p15Cols[a]) this.drawX(this.marksPhysical, phys.p15Cols[a], phys.r15E2);
        }

        if (doublesCount === 7) {
            this.drawX(this.marksPhysical, phys.cP, gP(14)); // P14 (7 dobles)
            this.drawX(this.marksPhysical, gP(26.8), gP(14.8)); // Casilla Reducción
        }

        doubleIndices.forEach(idx => {
            const rE = 2 + ((idx - 1) * 2);
            this.drawX(this.marksPhysical, phys.cT, gP(rE));
        });

        // ---------------------------------------------------------
        // 2. DIGITAL GRID
        // ---------------------------------------------------------
        const dig = { startY: 23.5, stepY: 4.02, c1: 60.5, cX: 62.1, c2: 63.7, sX: 72.2 };
        sel.forEach((sign, idx) => {
            if (idx === 14) return;
            const y = dig.startY + (idx * dig.stepY);
            if (sign.includes('1')) this.drawX(this.marksDigital, dig.c1, y);
            if (sign.includes('X')) this.drawX(this.marksDigital, dig.cX, y);
            if (sign.includes('2')) this.drawX(this.marksDigital, dig.c2, y);
            if (sign.length === 2) this.drawX(this.marksDigital, dig.sX, y);
        });

        this.marksDigital.innerHTML += '<div style="position:absolute; top:20px; right:20px; background:rgba(0, 71, 161, 0.95); color:white; padding:10px 20px; border-radius:30px; font-size:1rem; font-weight:900; box-shadow:0 8px 20px rgba(0,0,0,0.4); z-index:1000; border:2px solid #00e5ff;">GUÍA: ' + doublesCount + ' DOBLES</div>';
    }

    drawX(container, xPct, yPct) {
        const x = document.createElement('div');
        x.className = 'help-mark-x';
        x.textContent = 'X';
        x.style.left = xPct + '%';
        x.style.top = yPct + '%';
        container.appendChild(x);
    }

    async saveForecast() {
        try {
            console.log("🔵 PASO 1: saveForecast iniciado");
            console.log("IDs:", { mId: this.currentMemberId, jId: this.currentJornadaId });

            if (!this.currentMemberId || !this.currentJornadaId) {
                console.error("❌ Faltan IDs");
                alert("Error: No parece haber un socio o jornada seleccionados válidos. Intenta refrescar o seleccionar de nuevo.");
                return;
            }

            console.log("🔵 PASO 2: Obteniendo selecciones");
            const rows = this.container.querySelectorAll('.p-options');
            console.log("Filas encontradas:", rows.length);

            const selection = [];
            let missing = false;

            rows.forEach((r, i) => {
                const isPlenoDisabled = (i === 14 && (
                    r.style.pointerEvents === 'none' ||
                    r.style.opacity === '0.3' ||
                    parseFloat(window.getComputedStyle(r).opacity) < 0.5
                ));

                const sel = r.querySelector('.selected');
                if (sel) selection.push(sel.textContent);
                else {
                    selection.push(null);
                    if (!isPlenoDisabled) missing = true;
                }
            });

            console.log("🔵 PASO 3: Selección:", selection);
            console.log("¿Falta algo?", missing);

            // Allow saving if it's completely empty (Clearing action)
            const isFullyEmpty = selection.every(s => s === null || s === '-');

            if (missing && !isFullyEmpty) {
                alert('Debes rellenar todos los resultados disponibles.');
                return;
            }

            console.log("🔵 PASO 4: Buscando jornada");
            const jornada = this.jornadas.find(j => j.id == this.currentJornadaId);
            if (!jornada) {
                alert("Error: No se encuentra la jornada seleccionada.");
                return;
            }
            console.log("Jornada encontrada:", jornada.number);

            console.log("🔵 PASO 5: Comprobando estado de bloqueo");
            const { isLockedRef, hasStarted, isFinished } = this.isJornadaLocked(jornada);
            if (isLockedRef && !this.correctionMode) {
                const existing = this.pronosticos.find(p => (p.jId == this.currentJornadaId || p.jornadaId == this.currentJornadaId) && (p.mId == this.currentMemberId || p.memberId == this.currentMemberId));
                const hasExisting = existing && Array.isArray(existing.selection) && existing.selection.some(s => s && String(s).trim() !== '' && String(s).trim() !== '-');

                if (!hasExisting && hasStarted) {
                    alert("No es posible rellenar la quiniela: la jornada ya cuenta con resultados de partidos registrados. Solo se admiten pronósticos con retraso antes de que comience la jornada.");
                } else {
                    alert("Esta jornada está bloqueada y no admite cambios sin activar el Modo Corrección.");
                }
                return;
            }

            const deadline = this.calculateDeadline(jornada.date);
            const now = new Date();
            const isLate = deadline ? (now > deadline) : false;

            const isReduced = this.selMethod && this.selMethod.value === 'reducido';
            if (isReduced) {
                const doubleCount = selection.filter((s, i) => i < 14 && s && s.length > 1).length;
                if (doubleCount !== 7) {
                    alert(`Error: El método 'Reducida' requiere exactamente 7 dobles. Actualmente tienes ${doubleCount}.`);
                    return;
                }
            }

            const id = `${this.currentJornadaId}_${this.currentMemberId}`;
            const record = {
                id: id,
                jId: this.currentJornadaId,
                mId: this.currentMemberId,
                selection: selection,
                isReduced: isReduced,
                timestamp: new Date().toISOString(),
                late: isLate,
                isDice: false
            };

            console.log("🔵 PASO 7: Verificando si necesita auditoría");
            console.log("Condición:", `isLockedRef=${isLockedRef} && correctionMode=${this.correctionMode}`);

            // If LOCKED and CORRECTION MODE -> Audit Flow
            if (isLockedRef && this.correctionMode) {
                console.log("🟢 ABRIENDO MODAL DE AUDITORÍA");
                this.pendingSaveData = record;
                this.openAuditModal(isLate);
                return;
            }

            console.log("🔵 PASO 8: Guardado normal (sin auditoría)");
            await this.performFinalSave(record, isLate);

        } catch (error) {
            console.error("❌ ERROR CAPTURADO:", error);
            alert("Error inesperado al guardar: " + error.message);
        }
    }

    openAuditModal(isLateCurrent) {
        console.log("🟡 openAuditModal llamado");
        console.log("Modal element:", this.auditModal);

        if (!this.auditModal) {
            console.error("❌ auditModal es null!");
            alert("Error: No se encuentra el modal de auditoría en la página.");
            return;
        }

        // Bloquear scroll del body
        document.body.style.overflow = 'hidden';

        // Mostrar modal
        this.auditModal.classList.add('active');
        this.auditReason.value = '';
        this.auditLateCheck.checked = isLateCurrent;

        // Focus en el textarea
        setTimeout(() => {
            if (this.auditReason) this.auditReason.focus();
        }, 100);

        console.log("✅ Modal mostrado (display=flex)");
    }

    async executeAuditSave() {
        if (!this.pendingSaveData) return;

        const reason = this.auditReason.value.trim();
        if (!reason) {
            alert('Por favor, indica un motivo para la corrección.');
            return;
        }

        const isForceLate = this.auditLateCheck.checked;

        // Disable button to prevent double clicking and show status
        if (this.btnConfirmAudit) {
            this.btnConfirmAudit.disabled = true;
            this.btnConfirmAudit.textContent = 'Guardando...';
        }

        try {
            console.log("🔵 Iniciando proceso de guardado de auditoría...");

            // 1. Prepare Log Entry
            const existing = this.pronosticos.find(p => p.id == this.pendingSaveData.id);
            const logEntry = {
                timestamp: new Date().toISOString(),
                type: 'CORRECTION',
                memberId: this.currentMemberId,
                jornadaId: this.currentJornadaId,
                oldSelection: existing ? existing.selection : null,
                newSelection: this.pendingSaveData.selection,
                reason: reason,
                forcedLate: isForceLate
            };

            // 2. Save Log
            if (window.DataService) {
                console.log("Saving log entry...");
                await window.DataService.save('modification_logs', logEntry);
            }

            // 3. Update Record with Forced Late Status
            this.pendingSaveData.late = isForceLate;

            // 4. Save Record
            console.log("Saving record...");
            await this.performFinalSave(this.pendingSaveData, isForceLate, true);

            // 5. Success Flow: Close modal
            this.auditModal.classList.remove('active');
            document.body.style.overflow = ''; // Restaurar scroll
            this.pendingSaveData = null;

        } catch (error) {
            console.error("❌ ERROR CRÍTICO EN executeAuditSave:", error);
            alert("Error al guardar la corrección: " + error.message);
        } finally {
            if (this.btnConfirmAudit) {
                this.btnConfirmAudit.disabled = false;
                this.btnConfirmAudit.textContent = 'Confirmar Cambio';
            }
        }
    }

    async performFinalSave(record, isLate, isCorrection = false) {
        const idx = this.pronosticos.findIndex(p => p.id == record.id);
        if (idx > -1) {
            this.pronosticos[idx] = { ...this.pronosticos[idx], ...record };
        } else {
            this.pronosticos.push(record);
        }

        await window.DataService.save('pronosticos', record);

        if (isCorrection) {
            alert('✅ CORRECCIÓN APLICADA Y REGISTRADA CORRECTAMENTE');
        } else {
            // Show random Maula phrase
            if (typeof FRASES_MAULA !== 'undefined' && FRASES_MAULA.length > 0) {
                const randomPhrase = FRASES_MAULA[Math.floor(Math.random() * FRASES_MAULA.length)];
                alert('PRONÓSTICO GUARDADO CORRECTAMENTE\n\n' + randomPhrase);
            } else {
                alert('Pronóstico guardado correctamente' + (isLate ? ' (CON RETRASO)' : '') + '.');
            }
        }

        this.renderSummaryTable(); // Refresh summary

        // Check for Habemus Quinielam (Telegram)
        if (window.TelegramService && !isCorrection) {
            setTimeout(() => {
                window.TelegramService.checkHabemusQuinielam(this.currentJornadaId);
            }, 1000); // Small delay to ensure DB propagation
        }
    }

    isJornadaLocked(jornada) {
        if (!jornada) return { isLockedRef: false, isFinished: false, hasStarted: false };

        const now = new Date();
        const dateObj = AppUtils.parseDate(jornada.date);
        let isPastCloseDate = false;
        if (dateObj) {
            const closeDate = new Date(dateObj);
            closeDate.setDate(closeDate.getDate() + 2);
            closeDate.setHours(23, 59, 59);
            isPastCloseDate = now > closeDate;
        }

        const hasStarted = Array.isArray(jornada.matches) && jornada.matches.some(m => {
            if (!m) return false;
            const r = (m.result !== undefined && m.result !== null) ? String(m.result).trim() : '';
            const isResultValid = r !== '' && r !== '-' && r.toLowerCase() !== 'por definir';
            const s = (m.score !== undefined && m.score !== null) ? String(m.score).trim() : '';
            const isScoreValid = s !== '' && s !== '-' && s.toLowerCase() !== 'por definir';
            return isResultValid || isScoreValid;
        });

        const isExplicitInactive = jornada.active === false;
        const isFinished = isExplicitInactive || isPastCloseDate || (Array.isArray(jornada.matches) && jornada.matches.length === 15 && jornada.matches.every(m => {
            if (!m || !m.result) return false;
            const r = String(m.result).trim();
            return r !== '' && r !== '-' && r.toLowerCase() !== 'por definir';
        }));

        const isLockedRef = isFinished || hasStarted;

        return { isLockedRef, isFinished, hasStarted };
    }

    calculateDeadline(dateStr) {
        return window.AppUtils ? window.AppUtils.calculateDeadline(dateStr) : null;
    }

    renderSummaryTable() {
        if (!this.summaryTable) return;

        const thead = this.summaryTable.querySelector('thead');
        const tbody = this.summaryTable.querySelector('tbody');
        thead.innerHTML = '';
        tbody.innerHTML = '';

        // 1. Sort Members alphabetically
        const sortedMembers = [...this.members].sort((a, b) => parseInt(a.id) - parseInt(b.id));

        // 2. Build Header
        const headerRow = document.createElement('tr');
        const stickyTh = document.createElement('th');
        stickyTh.className = 'summary-sticky-col summary-header-cell';
        stickyTh.textContent = 'Jornada';
        headerRow.appendChild(stickyTh);

        sortedMembers.forEach((m, index) => {
            const th = document.createElement('th');
            th.className = 'summary-header-cell';
            th.textContent = AppUtils.getMemberName(m);
            headerRow.appendChild(th);
        });

        // Add Quiniela Dobles column header at the end
        const thDoubles = document.createElement('th');
        thDoubles.className = 'summary-header-cell summary-doubles-header';
        thDoubles.textContent = 'Quiniela Dobles';
        headerRow.appendChild(thDoubles);

        thead.appendChild(headerRow);

        // OPTIMIZATION: Build Maps for O(1) lookups
        const pronosticosMap = new Map();
        const jornadasConPronostico = new Set();
        
        if (this.pronosticos && Array.isArray(this.pronosticos)) {
            this.pronosticos.forEach(p => {
                if (!p) return;
                const jIds = [];
                if (p.jId !== undefined && p.jId !== null) jIds.push(String(p.jId));
                if (p.jornadaId !== undefined && p.jornadaId !== null) jIds.push(String(p.jornadaId));
                
                const mIds = [];
                if (p.mId !== undefined && p.mId !== null) mIds.push(String(p.mId));
                if (p.memberId !== undefined && p.memberId !== null) mIds.push(String(p.memberId));

                jIds.forEach(j => {
                    jornadasConPronostico.add(j);
                    mIds.forEach(m => {
                        const key = `${j}_${m}`;
                        if (!pronosticosMap.has(key)) {
                            pronosticosMap.set(key, p);
                        }
                    });
                });
            });
        }

        // Map for pronosticosExtra (Quiniela de Dobles)
        const pronosticosExtraMap = new Map();
        const jornadasConDobles = new Set();
        if (this.pronosticosExtra && Array.isArray(this.pronosticosExtra)) {
            this.pronosticosExtra.forEach(p => {
                if (!p) return;
                const jId = String(p.jId !== undefined && p.jId !== null ? p.jId : p.jornadaId);
                const hasValidSelection = p.selection && Array.isArray(p.selection) && p.selection.some(s => s && String(s).trim() !== '' && String(s) !== '-');
                if (hasValidSelection) {
                    jornadasConDobles.add(jId);
                    pronosticosExtraMap.set(jId, p);
                }
            });
        }

        // 3. Sort Jornadas (descending) & Filter empty ones
        let sortedJornadas = [...this.jornadas].sort((a, b) => b.number - a.number);

        // Filter: Keep jornadas that have matches informed OR have at least one forecast saved
        sortedJornadas = sortedJornadas.filter(j => {
            const hasMatches = j.matches && j.matches.some(m => m.home && m.home.trim() !== '');
            const hasForecasts = jornadasConPronostico.has(String(j.id));
            const hasDobles = jornadasConDobles.has(String(j.id));

            return hasMatches || hasForecasts || hasDobles;
        });

        if (sortedJornadas.length === 0) {
            tbody.innerHTML = '<tr><td colspan="100%" style="padding:2rem;">No hay pronósticos registrados aún.</td></tr>';
            return;
        }

        // 4. Build Rows using string concatenation for maximum performance
        let tbodyHtml = '';
        
        sortedJornadas.forEach(j => {
            let dateFormatted = j.date;
            try {
                const d = AppUtils.parseDate(j.date);
                if (d) {
                    dateFormatted = d.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' });
                }
            } catch (e) { }

            const hasPig = (j.matches || []).some(m => m && typeof AppUtils !== 'undefined' && AppUtils.isPigMatch(m.home, m.away));
            let rowHtml = `<tr>
                <td class="summary-sticky-col summary-jornada-info">
                    <div class="summary-j-num">J${j.number}${hasPig ? ' 🐷' : ''}</div>
                    <div class="summary-j-date">${dateFormatted}</div>
                </td>`;

            sortedMembers.forEach((m, index) => {
                const jIdStr = String(j.id);
                const mIdStr = String(m.id);
                const p = pronosticosMap.get(`${jIdStr}_${mIdStr}`);
                const isEven = index % 2 !== 0;

                let cellContent = '-';
                let cellClass = `summary-cell ${isEven ? 'col-even' : 'col-odd'} hoverable-cell`;

                let isPlayed = false;
                if (p && p.selection && Array.isArray(p.selection)) {
                    isPlayed = p.selection.some(s => s && String(s).trim() !== '' && String(s) !== '-');
                }

                if (isPlayed) {
                    const selection14 = p.selection.slice(0, 14);
                    const b1 = selection14.slice(0, 4).map(s => s || '-').join('');
                    const b2 = selection14.slice(4, 8).map(s => s || '-').join('');
                    const b3 = selection14.slice(8, 11).map(s => s || '-').join('');
                    const b4 = selection14.slice(11, 14).map(s => s || '-').join('');

                    let p15Val = '';
                    if (p.selection && p.selection[14]) {
                        const raw = String(p.selection[14]).trim();
                        if (raw && raw !== '-') p15Val = raw;
                    }

                    const lateClass = p.late ? ' late' : '';
                    const lateTitle = p.late ? ' (Enviado con retraso)' : '';
                    const diceBadge = p.isDice ? '<span class="sf-dice-badge" title="Relleno con Dado 🎲">🎲</span>' : '';
                    const p15Badge = p15Val ? `<span class="sf-p15-badge" title="Pleno al 15: ${p15Val}">P15: ${p15Val}</span>` : '';

                    cellContent = `
                        <div class="summary-forecast${lateClass}" title="Pronóstico${lateTitle}${p.isDice ? ' (Relleno con Dado 🎲)' : ''}">
                            ${diceBadge}
                            <span class="sf-block">${b1}</span>
                            <span class="sf-sep">|</span>
                            <span class="sf-block">${b2}</span>
                            <span class="sf-sep">|</span>
                            <span class="sf-block">${b3}</span>
                            <span class="sf-sep">|</span>
                            <span class="sf-block">${b4}</span>
                            ${p15Badge}
                        </div>
                    `;
                } else {
                    cellContent = `<span class="summary-no-data">-</span>`;
                }

                rowHtml += `<td class="${cellClass}" data-jid="${j.id}" data-mid="${m.id}">${cellContent}</td>`;
            });

            // 5. Add Quiniela de Dobles cell for this jornada
            const jIdStr = String(j.id);
            const pExtra = pronosticosExtraMap.get(jIdStr);
            let doublesContent = '-';
            let isDoublesPlayed = false;

            if (pExtra && pExtra.selection && Array.isArray(pExtra.selection)) {
                isDoublesPlayed = pExtra.selection.some(s => s && String(s).trim() !== '' && String(s) !== '-');
            }

            if (isDoublesPlayed) {
                const selection14 = (pExtra.selection && Array.isArray(pExtra.selection)) ? pExtra.selection.slice(0, 14) : [];
                let gridColsHtml = '';

                for (let idx = 0; idx < 14; idx++) {
                    const s = selection14[idx];
                    const signStr = (s && typeof s === 'string') ? s.trim() : (s !== undefined && s !== null ? String(s).trim() : '');
                    
                    let mainSign = '-';
                    let subSign = '-';
                    let isSubActive = false;

                    if (signStr && signStr !== '-') {
                        mainSign = signStr.charAt(0) || '-';
                        if (signStr.length > 1) {
                            subSign = signStr.charAt(1);
                            isSubActive = true;
                        }
                    }

                    const isBlockEnd = [3, 7, 10].includes(idx);
                    const subClass = isSubActive ? 'sign-sub active' : 'sign-sub empty';
                    const blockEndClass = isBlockEnd ? ' block-end' : '';
                    gridColsHtml += `
                        <div class="doubles-col${blockEndClass}">
                            <span class="sign-main">${mainSign}</span>
                            <span class="${subClass}">${subSign}</span>
                        </div>
                    `;
                }

                let p15Val = '-';
                if (pExtra.selection && Array.isArray(pExtra.selection) && pExtra.selection[14]) {
                    const rawP15 = String(pExtra.selection[14]).trim();
                    if (rawP15 && rawP15 !== '-') {
                        p15Val = rawP15;
                    }
                }

                const p15BadgeClass = p15Val !== '-' ? 'doubles-p15-badge' : 'doubles-p15-badge empty';
                const p15Badge = `<span class="${p15BadgeClass}" title="Pleno al 15">P15: ${p15Val}</span>`;

                doublesContent = `
                    <div class="summary-doubles-container">
                        <div class="doubles-grid-wrapper">
                            <div class="doubles-grid">
                                ${gridColsHtml}
                            </div>
                            ${p15Badge}
                        </div>
                    </div>
                `;
            } else {
                doublesContent = `<span class="summary-no-data">-</span>`;
            }

            const doublesCellClass = `summary-cell summary-doubles-cell hoverable-cell`;
            const doublesMemberId = pExtra ? (pExtra.mId || pExtra.memberId || '') : '';
            rowHtml += `<td class="${doublesCellClass}" data-jid="${j.id}" data-mid="${doublesMemberId}" data-isdoubles="true">${doublesContent}</td>`;

            rowHtml += '</tr>';
            tbodyHtml += rowHtml;
        });
        
        tbody.innerHTML = tbodyHtml;

        // Horizontal Scroll Sync (Double Scrollbar)
        this.applyDoubleScrollbar();
    }

    applyDoubleScrollbar() {
        if (!this.summaryContainer || !this.summaryTable) return;

        // Create or find the top scroll wrapper
        let topWrapper = document.getElementById('top-scroll-wrapper');
        if (!topWrapper) {
            topWrapper = document.createElement('div');
            topWrapper.id = 'top-scroll-wrapper';
            topWrapper.style.overflowX = 'auto';
            topWrapper.style.overflowY = 'hidden';
            topWrapper.style.WebkitOverflowScrolling = 'touch'; // Habilita inercia
            topWrapper.style.width = '100%';
            topWrapper.style.height = '20px'; // Minimum height for scrollbar
            topWrapper.innerHTML = '<div id="top-scroll-content" style="height:1px;"></div>';
            this.summaryContainer.parentElement.insertBefore(topWrapper, this.summaryContainer);
        }

        const topContent = document.getElementById('top-scroll-content');
        const container = this.summaryContainer;
        const table = this.summaryTable;

        // En móviles/tablets, el doble scrollbar no es necesario y rompe la inercia nativa de iOS.
        const isTouch = window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 1024;
        
        if (isTouch) {
            topWrapper.style.display = 'none';
            // Limpiamos los eventos por si se redimensiona la pantalla
            container.onscroll = null;
            topWrapper.onscroll = null;
            return;
        } else {
            topWrapper.style.display = 'block';
        }

        // Sync contents width
        const updateWidth = () => {
            topContent.style.width = table.offsetWidth + 'px';
        };

        // Initial and on resize
        updateWidth();
        window.addEventListener('resize', updateWidth);

        // Sync scroll events for Desktop (Mouse)
        let isSyncingLeft = false;
        let isSyncingRight = false;
        
        topWrapper.onscroll = function () {
            if (!isSyncingLeft) {
                isSyncingRight = true;
                window.requestAnimationFrame(() => {
                    container.scrollLeft = topWrapper.scrollLeft;
                    setTimeout(() => { isSyncingRight = false; }, 10);
                });
            }
        };
        container.onscroll = function () {
            if (!isSyncingRight) {
                isSyncingLeft = true;
                window.requestAnimationFrame(() => {
                    topWrapper.scrollLeft = container.scrollLeft;
                    setTimeout(() => { isSyncingLeft = false; }, 10);
                });
            }
        };
    }

    async showJornadaForecasts(specificJId = null) {
        try {
            let jId = specificJId || this.currentJornadaId;

            console.log("DEBUG: Opening Technical Panel for JID:", jId);

            // Auto-select latest jornada that HAS informed matches if none selected
            if (!jId) {
                const informed = this.jornadas
                    .filter(j => j.matches && j.matches.some(m => m.home && m.home.trim() !== ''))
                    .sort((a, b) => b.number - a.number);

                if (informed.length > 0) {
                    jId = informed[0].id;
                    console.log("DEBUG: No JID selected, auto-picked latest informed:", jId);
                }
            }

            if (!jId) {
                alert('No se puede abrir el panel: No hay jornadas configuradas con partidos.');
                return;
            }

            const jornada = this.jornadas.find(j => String(j.id) === String(jId));
            if (!jornada || !jornada.matches) {
                alert('No se encontró información de la jornada.');
                return;
            }

            // Populate Modal Dropdown if empty
            if (this.selModalJornada && (this.selModalJornada.options.length === 0 || this.selModalJornada.innerHTML.trim() === '')) {
                this.selModalJornada.innerHTML = '';
                const informed = this.jornadas
                    .filter(j => j.matches && j.matches.some(m => m.home))
                    .sort((a, b) => b.number - a.number);

                informed.forEach(j => {
                    const opt = document.createElement('option');
                    opt.value = j.id;
                    opt.textContent = `Jornada ${j.number}`;
                    this.selModalJornada.appendChild(opt);
                });
            }
            if (this.selModalJornada) this.selModalJornada.value = String(jId);

            console.log("SHOWING TECHNICAL PANEL FOR JORNADA:", jId);

            // Fetch all base forecasts for this jornada
            const allForecasts = this.pronosticos.filter(p => String(p.jId || p.jornadaId) === String(jId));

            // Fetch all doubles forecasts for this jornada
            const allDoubles = (this.pronosticosExtra || []).filter(p => String(p.jId || p.jornadaId) === String(jId));

            // Sort members by ID (Member Number)
            const sortedMembers = [...this.members].sort((a, b) => parseInt(a.id) - parseInt(b.id));

            this.viewJornadaTitle.textContent = `Ver Pronósticos - Jornada ${jornada.number}`;
            this.viewJornadaContent.innerHTML = '<p style="padding:40px; font-size:1.2rem; font-weight:bold; color:#673ab7; animation: blink 1s infinite;">⚙️ Procesando datos y generando tabla...</p>';

            // Critical fix: Ensure opacity is 1 and z-index is high
            this.viewJornadaModal.style.display = 'flex';
            this.viewJornadaModal.style.opacity = '1';
            this.viewJornadaModal.style.zIndex = '999999';

            const isMobile = window.innerWidth <= 768;

            if (this.btnCloseMobileFloat) {
                this.btnCloseMobileFloat.style.display = isMobile ? 'block' : 'none';
            }

            const fSizeTable = isMobile ? '0.8rem' : '1.05rem';
            const fSizeTh = isMobile ? '0.85rem' : '1.1rem';
            const padTh = isMobile ? '6px' : '15px';
            const padTdNum = isMobile ? '6px' : '10px';
            const padTdTeam = isMobile ? '6px' : '10px 20px';
            const padTdCell = isMobile ? '4px' : '8px';

            const wNum = isMobile ? 35 : 50;
            const wTeam = isMobile ? 85 : 200;
            const wMember = isMobile ? 32 : 60;
            const hMember = isMobile ? 120 : 220;
            const fSizeMember = isMobile ? '0.8rem' : '0.95rem';
            const fSizeCell = isMobile ? '0.9rem' : '1.25rem';

            const strWNum = wNum + 'px';
            const strWTeam = wTeam + 'px';
            const strWMember = wMember + 'px';
            const strHMember = hMember + 'px';

            const leftNum = '0px';
            const leftHome = wNum + 'px';
            const leftAway = (wNum + wTeam) + 'px';

            // Build Enhanced Table (Much LARGER as requested)
            let html = `
                <table style="border-collapse: separate; border-spacing: 0; font-size: ${fSizeTable}; background: #fff; width: auto; min-width: ${isMobile ? '100%' : '95%'}; margin-bottom: 40px; border: 3px solid var(--primary-orange); border-radius: 8px;">
                    <thead style="background: #e0e0e0; position: sticky; top: 0; z-index: 100;">
                        <tr>
                            <th style="position: sticky; left: ${leftNum}; z-index: 110; background: #e0e0e0; border: 1px solid #ccc; padding: ${padTh}; min-width: ${strWNum}; max-width: ${strWNum}; color: #333; font-size: ${fSizeTh};">#</th>
                            <th style="position: sticky; left: ${leftHome}; z-index: 110; background: #e0e0e0; border: 1px solid #ccc; padding: ${padTh}; text-align: right; min-width: ${strWTeam}; max-width: ${strWTeam}; color: #333; font-size: ${fSizeTh}; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">Local</th>
                            <th style="position: sticky; left: ${leftAway}; z-index: 110; background: #e0e0e0; border: 1px solid #ccc; padding: ${padTh}; text-align: left; min-width: ${strWTeam}; max-width: ${strWTeam}; color: #333; font-size: ${fSizeTh}; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">Visitante</th>
            `;

            // Member Columns
            sortedMembers.forEach(m => {
                const f = allForecasts.find(p => String(p.mId || p.memberId) === String(m.id));
                const diceIcon = (f && f.isDice) ? ' 🎲' : '';
                html += `<th title="${m.name}${diceIcon ? ' (Relleno con Dado)' : ''}" style="border: 1px solid #ccc; padding: ${padTdCell}; writing-mode: vertical-lr; transform: rotate(180deg); text-align: center; height: ${strHMember}; width: ${strWMember}; min-width: ${strWMember}; font-size: ${fSizeMember}; color: #333; font-weight: 600; white-space: nowrap; overflow:hidden;">${m.name}${diceIcon}</th>`;
            });

            // Doubles Columns at the end
            allDoubles.forEach(() => {
                html += `<th style="border: 2px solid var(--primary-orange); padding: ${padTdCell}; writing-mode: vertical-lr; transform: rotate(180deg); text-align: center; height: ${strHMember}; width: ${strWMember}; min-width: ${strWMember}; font-size: ${isMobile ? '0.8rem' : '1rem'}; color: #fff; background: var(--primary-orange); font-weight: bold; letter-spacing: 1px; white-space: nowrap;">Quiniela Dobles</th>`;
            });

            // "COLUMNA PERFECTA" Logic
            let perfectColumn = null;
            let perfectHits = 0;
            const allResolved = sortedMembers.every(m => allForecasts.some(p => String(p.mId || p.memberId) === String(m.id)));

            if (allResolved) {
                perfectColumn = this.calculatePerfectColumn(jornada);
                html += `<th style="border: 3px solid #ffd700; padding: ${padTdCell}; writing-mode: vertical-lr; transform: rotate(180deg); text-align: center; height: ${strHMember}; width: ${strWMember}; min-width: ${strWMember}; font-size: ${isMobile ? '0.8rem' : '0.9rem'}; color: #000; background: linear-gradient(to bottom, #ffd700, #ffecb3); font-weight: 900; letter-spacing: 1px; white-space: nowrap; box-shadow: inset 0 0 10px rgba(0,0,0,0.1);">⭐ COLUMNA MAULA</th>`;
            }

            // Results Column Header
            html += `<th style="border: 1px solid #333; padding: ${padTdCell}; writing-mode: vertical-lr; transform: rotate(180deg); text-align: center; height: ${strHMember}; width: ${strWMember}; min-width: ${strWMember}; font-size: ${isMobile ? '0.9rem' : '1.1rem'}; color: #fff; background: #333; font-weight: bold; letter-spacing: 1px; white-space: nowrap;">RESULTADO REAL</th>`;


            html += `</tr></thead><tbody>`;

            // Hit counters for summary row
            const baseHitsCount = {}; // { memberId: hits }
            const doublesHitsCount = {}; // { doubleIndex: hits }
            sortedMembers.forEach(m => baseHitsCount[m.id] = 0);
            allDoubles.forEach((_, idx) => doublesHitsCount[idx] = 0);

            const totalCols = 3 + sortedMembers.length + allDoubles.length + (perfectColumn ? 1 : 0) + 1;

            jornada.matches.forEach((match, idx) => {
                const displayIdx = idx === 14 ? 'P15' : idx + 1;
                const isBlockEnd = [3, 7, 10, 13].includes(idx);
                const isP15Divider = idx === 13;
                const blockBottomBorder = isBlockEnd ? (isP15Divider ? 'border-bottom: 4px solid var(--primary-orange, #ff9100) !important;' : 'border-bottom: 3px solid #757575 !important;') : '';
                const bgColor = idx % 2 === 0 ? '#fff' : '#f5f5f5';

                const officialResult = match.result || null;

                html += `<tr>
                    <td style="position: sticky; left: ${leftNum}; z-index: 5; background: ${bgColor}; border: 1px solid #ccc; ${blockBottomBorder} padding: ${padTdNum}; text-align: center; font-weight: bold; color: var(--primary-orange); font-size: ${fSizeTh}; max-width: ${strWNum}; overflow: hidden;">${displayIdx}</td>
                    <td style="position: sticky; left: ${leftHome}; z-index: 5; background: ${bgColor}; border: 1px solid #ccc; ${blockBottomBorder} padding: ${padTdTeam}; text-align: right; max-width: ${strWTeam}; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 600; color: #333;">${match.home}</td>
                    <td style="position: sticky; left: ${leftAway}; z-index: 5; background: ${bgColor}; border: 1px solid #ccc; ${blockBottomBorder} padding: ${padTdTeam}; text-align: left; max-width: ${strWTeam}; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 600; color: #333;">${match.away}</td>
                `;

                // Individual Forecasts
                sortedMembers.forEach(m => {
                    const f = allForecasts.find(p => String(p.mId || p.memberId) === String(m.id));
                    let sign = '-';
                    let cellStyle = `border: 1px solid #ccc; padding: ${padTdCell}; text-align: center; width: ${strWMember}; min-width: ${strWMember}; font-weight: bold; font-size: ${fSizeCell};`;

                    if (f && f.selection && f.selection[idx]) {
                        sign = f.selection[idx];
                        const isHit = officialResult && sign === officialResult;

                        if (sign === '1') cellStyle += 'color: #1976d2;';
                        else if (sign === 'X') cellStyle += 'color: #757575;';
                        else if (sign === '2') cellStyle += 'color: #d32f2f;';

                        if (isHit) {
                            cellStyle += 'background: #c8e6c9; border: 2px solid #2e7d32;'; // Light green for hit
                            baseHitsCount[m.id]++;
                        } else if (f.late && !f.pardoned) {
                            cellStyle += 'background: #fff3e0;';
                        }
                    }

                    html += `<td style="${cellStyle} ${blockBottomBorder}">${sign}</td>`;
                });

                // Doubles Forecasts (Extra columns)
                allDoubles.forEach((db, dbIdx) => {
                    let sign = '-';
                    let cellStyle = `border: 2px solid var(--primary-orange); padding: ${padTdCell}; text-align: center; width: ${strWMember}; min-width: ${strWMember}; font-weight: 900; font-size: ${fSizeCell}; color: #fff; background: var(--primary-orange);`;

                    if (db.selection && db.selection[idx]) {
                        sign = db.selection[idx];
                        const isHit = officialResult && sign.includes(officialResult);

                        if (isHit) {
                            cellStyle += 'background: #81c784; color: #fff; border: 2px solid #1b5e20;'; // Darker green for doubles hit
                            doublesHitsCount[dbIdx]++;
                        }
                    }
                    html += `<td style="${cellStyle} ${blockBottomBorder}">${sign}</td>`;
                });

                // Perfect Column Cell
                if (perfectColumn) {
                    const sign = perfectColumn[idx] || '-';
                    let cellStyle = `border: 3px solid #ffd700; padding: ${padTdCell}; text-align: center; width: ${strWMember}; min-width: ${strWMember}; font-weight: 900; font-size: ${fSizeCell}; color: #b8860b; background: #fffde7;`;
                    const isHit = officialResult && sign === officialResult;
                    if (isHit) {
                        cellStyle += 'background: #ffd700; color: #000; border: 3px solid #ffa000;';
                        perfectHits++;
                    }
                    html += `<td style="${cellStyle} ${blockBottomBorder}">${sign}</td>`;
                }

                // Official Result Cell
                const resVal = officialResult || '-';
                html += `<td style="border: 1px solid #333; ${blockBottomBorder} padding: ${padTdCell}; text-align: center; width: ${strWMember}; min-width: ${strWMember}; font-weight: 900; font-size: ${isMobile ? '1.1rem' : '1.5rem'}; color: #fff; background: #444;">${resVal}</td>`;

                html += `</tr>`;

                if (isBlockEnd) {
                    if (isP15Divider) {
                        html += `
                            <tr class="table-block-divider table-p15-divider">
                                <td colspan="${totalCols}" style="background: linear-gradient(90deg, #e65100, #ff9100, #e65100); height: 26px; text-align: center; color: #fff; font-size: ${isMobile ? '0.75rem' : '0.85rem'}; font-weight: 900; letter-spacing: 2px; padding: 3px 0; border-top: 2px solid #bf360c; border-bottom: 2px solid #bf360c;">
                                    ★ PLENO AL 15 ★
                                </td>
                            </tr>
                        `;
                    } else {
                        html += `
                            <tr class="table-block-divider">
                                <td colspan="${totalCols}" style="background: #ff3600; height: 2px; border: none; padding: 0;"></td>
                            </tr>
                        `;
                    }
                }
            });

            html += `</tbody>`;

            // SUMMARY ROW (Final Hits)
            html += `<tfoot style="background: #eee; position: sticky; bottom: 0; z-index: 10;">
                <tr style="border-top: 3px solid #673ab7; height: ${isMobile ? '40px' : '60px'};">
                    <td colspan="3" style="text-align: right; padding: ${padTdNum}; font-weight: 900; color: #673ab7; font-size: ${isMobile ? '0.9rem' : '1.2rem'}; background: #f3e5f5;">TOTAL ACIERTOS:</td>
            `;

            sortedMembers.forEach(m => {
                const hits = baseHitsCount[m.id];
                html += `<td style="border: 1px solid #ccc; text-align: center; font-weight: 900; font-size: ${isMobile ? '1.1rem' : '1.5rem'}; color: #2e7d32; background: #e8f5e9;">${hits}</td>`;
            });

            allDoubles.forEach((_, idx) => {
                const hits = doublesHitsCount[idx];
                html += `<td style="border: 2px solid #673ab7; text-align: center; font-weight: 900; font-size: ${isMobile ? '1.2rem' : '1.6rem'}; color: #fff; background: #2e7d32;">${hits}</td>`;
            });

            if (perfectColumn) {
                html += `<td style="border: 3px solid #ffa000; text-align: center; font-weight: 900; font-size: ${isMobile ? '1.3rem' : '1.8rem'}; color: #000; background: #ffd700;">${perfectHits}</td>`;
            }

            // Empty cell for Results column in footer
            html += `<td style="background: #333; border: 1px solid #333;"></td>`;


            html += `</tr></tfoot></table>`;

            this.viewJornadaContent.innerHTML = html;
            this.viewJornadaContent.style.overflowY = 'auto';

            // Verify visibility logic
            if (window.getComputedStyle(this.viewJornadaModal).opacity === "0") {
                this.viewJornadaModal.style.opacity = '1';
            }

            // Update navigation button states
            this.updateNavigationButtons();


        } catch (err) {
            console.error("CRITICAL ERROR IN TECHNICAL PANEL:", err);
            alert("Error al abrir el panel técnico: " + err.message);
            if (this.viewJornadaModal) this.viewJornadaModal.style.display = 'none';
        }
    }

    navigateJornada(direction) {
        if (!this.selModalJornada || this.selModalJornada.options.length === 0) {
            console.warn('No se puede navegar: dropdown no disponible');
            return;
        }

        const currentIndex = this.selModalJornada.selectedIndex;
        let newIndex;

        // El dropdown está ordenado descendente: Jornada 10, 9, 8, 7...
        // Índice 0 = Jornada más reciente (número mayor)
        // Índice N = Jornada más antigua (número menor)

        if (direction === 'prev') {
            // Botón izquierdo: ir a jornada ANTERIOR (número menor)
            // Necesitamos avanzar en la lista (índice mayor)
            newIndex = currentIndex + 1;
        } else if (direction === 'next') {
            // Botón derecho: ir a jornada SIGUIENTE (número mayor)
            // Necesitamos retroceder en la lista (índice menor)
            newIndex = currentIndex - 1;
        } else {
            console.warn('Dirección de navegación no válida:', direction);
            return;
        }

        // Verificar límites
        if (newIndex >= 0 && newIndex < this.selModalJornada.options.length) {
            this.selModalJornada.selectedIndex = newIndex;
            const newJornadaId = this.selModalJornada.value;
            console.log(`Navegando a jornada ${newJornadaId} (índice ${newIndex})`);
            this.showJornadaForecasts(newJornadaId);
        } else {
            console.log('Límite alcanzado, no se puede navegar más');
        }

        // Actualizar estado de los botones
        this.updateNavigationButtons();
    }

    updateNavigationButtons() {
        if (!this.selModalJornada || !this.btnPrevJornada || !this.btnNextJornada) {
            console.warn('No se pueden actualizar botones de navegación: elementos no disponibles');
            return;
        }

        const currentIndex = this.selModalJornada.selectedIndex;
        const totalOptions = this.selModalJornada.options.length;

        console.log(`Actualizando botones: índice ${currentIndex} de ${totalOptions}`);

        // Botón PREV (◀): va a jornada anterior (número menor)
        // Está al final de la lista (índice mayor)
        const canGoPrev = currentIndex < totalOptions - 1;
        this.btnPrevJornada.disabled = !canGoPrev;
        this.btnPrevJornada.style.opacity = canGoPrev ? '1' : '0.3';
        this.btnPrevJornada.style.cursor = canGoPrev ? 'pointer' : 'not-allowed';

        // Botón NEXT (▶): va a jornada siguiente (número mayor)
        // Está al principio de la lista (índice menor)
        const canGoNext = currentIndex > 0;
        this.btnNextJornada.disabled = !canGoNext;
        this.btnNextJornada.style.opacity = canGoNext ? '1' : '0.3';
        this.btnNextJornada.style.cursor = canGoNext ? 'pointer' : 'not-allowed';
    }



    /**
     * REESCRITURA TOTAL: Lógica de elegibilidad para dobles.
     * Incluye sistema de DESEMPATE para garantizar un único ganador.
     */
    checkEligibility(currentJornadaNum, memberId) {
        // CORRECTION MODE BYPASS: If we are in correction mode, always allow managing doubles
        if (this.correctionMode) return { eligible: true };

        if (currentJornadaNum <= 1) {
            if (currentJornadaNum === 1) {
                const member = this.members.find(m => String(m.id) === String(memberId));
                if (member && (member.name.toLowerCase() === 'alvaro' || member.name.toLowerCase() === 'álvaro')) {
                    return { eligible: true, reason: 'winner' };
                }
            }
            return { eligible: false };
        }

        // 1. Encontrar la jornada previa REAL
        const sortedJornadas = [...this.jornadas].sort((a, b) => a.number - b.number);
        const prevJornada = sortedJornadas.filter(j => j.number < currentJornadaNum).pop();

        if (!prevJornada || !prevJornada.matches) {
            console.log("DOUBLES: No hay jornada previa registrada.");
            return { eligible: false };
        }

        // 2. Extraer resultados
        const officialResults = prevJornada.matches.map(m => m.result);
        const resultsFound = officialResults.filter(r => r && r !== '-').length;
        const jDate = AppUtils.parseDate(prevJornada.date);

        if (resultsFound < 14) {
            console.log(`DOUBLES: J${prevJornada.number} aún no tiene resultados suficientes.`);
            return { eligible: false };
        }

        // 3. CALCULAR DATOS DE TODOS LOS SOCIOS PARA LA JORNADA PREVIA
        const prizeThreshold = prevJornada.minHitsToWin || 10;
        const leaderboard = this.members.map(m => {
            const p = this.pronosticos.find(pred => {
                const pJid = String(pred.jId || pred.jornadaId || '');
                const pMid = String(pred.mId || pred.memberId || '');
                return pJid === String(prevJornada.id) && pMid === String(m.id);
            });

            if (!p || !p.selection) {
                return { id: String(m.id), name: m.name, points: -5, hits: 0, isLate: false, isPardoned: false };
            }

            const isLate = p.late && !p.pardoned;
            const isPardoned = p.pardoned || false;

            if (isLate) {
                return { id: String(m.id), name: m.name, points: ScoringSystem.calculateScore(0, jDate), hits: 0, isLate: true, isPardoned: false };
            }

            const ev = ScoringSystem.evaluateForecast(p.selection, officialResults, jDate);
            return { id: String(m.id), name: m.name, points: ev.points, hits: ev.hits, isLate: p.late || false, isPardoned: isPardoned };
        });

        // 4. FILTRAR CANDIDATOS ELEGIBLES: excluir tarde sin premio ni perdón
        const eligibleForWinner = leaderboard.filter(l => {
            // Can compete if: not late, OR late but pardoned, OR late but got prize
            if (!l.isLate) return true;
            if (l.isPardoned) return true;
            if (l.hits >= prizeThreshold) return true;
            return false;
        });

        if (eligibleForWinner.length === 0) {
            console.log(`DOUBLES: Ningún socio elegible en J${prevJornada.number}`);
            return { eligible: false };
        }

        // 5. ENCONTRAR MÁXIMO DE PUNTOS
        const maxPoints = Math.max(...eligibleForWinner.map(l => l.points));
        let winnerCandidates = eligibleForWinner.filter(l => l.points === maxPoints);

        console.log(`DOUBLES: J${prevJornada.number} - Candidatos con ${maxPoints} puntos:`, winnerCandidates.map(c => c.name));

        // 6. DESEMPATE RECURSIVO SI HAY EMPATE
        if (winnerCandidates.length > 1) {
            console.log(`DOUBLES: Empate detectado, aplicando desempate recursivo...`);
            winnerCandidates = this.resolveTieEligibility(winnerCandidates, prevJornada.number);
        }

        // 7. El ganador es el primero de la lista
        let absoluteWinnerId = null;
        if (winnerCandidates.length > 0 && winnerCandidates[0].points > -5) {
            absoluteWinnerId = winnerCandidates[0].id;
            console.log(`🏆 GANADOR ÚNICO J${prevJornada.number}: ${winnerCandidates[0].name} (${winnerCandidates[0].points} pts)`);
        }

        // 8. Verificación para el socio actual: GANADOR ABSOLUTO o 10+ ACIERTOS
        const myStats = leaderboard.find(l => String(l.id) === String(memberId));
        const isAbsoluteWinner = absoluteWinnerId && String(memberId) === String(absoluteWinnerId);
        const hasPrizeHits = myStats && myStats.hits >= prizeThreshold;

        const isEligible = isAbsoluteWinner || hasPrizeHits;

        if (isEligible) {
            console.log(`✅ ACCESO CONCEDIDO A DOBLES para ${this.members.find(m => String(m.id) === String(memberId))?.name} (${isAbsoluteWinner ? 'Ganador' : '10+ Aciertos'})`);
        }

        return {
            eligible: isEligible,
            reason: isEligible ? (isAbsoluteWinner ? 'winner' : 'hits') : 'not_winner'
        };
    }

    /**
     * Desempate recursivo: mira jornadas anteriores hasta encontrar un único ganador
     */
    resolveTieEligibility(candidates, currentJornadaNum) {
        const sortedJornadas = [...this.jornadas].sort((a, b) => a.number - b.number);
        let currentCandidates = [...candidates];

        // Empezar desde la jornada anterior a currentJornadaNum
        let checkJornadaNum = currentJornadaNum - 1;

        while (currentCandidates.length > 1 && checkJornadaNum >= 1) {
            const checkJornada = sortedJornadas.find(j => j.number === checkJornadaNum);

            if (!checkJornada || !checkJornada.matches) {
                checkJornadaNum--;
                continue;
            }

            const officialResults = checkJornada.matches.map(m => m.result);
            const resultsFound = officialResults.filter(r => r && r !== '-').length;

            if (resultsFound < 14) {
                checkJornadaNum--;
                continue;
            }

            const jDate = AppUtils.parseDate(checkJornada.date);

            // Calcular puntos de cada candidato en esta jornada histórica
            const historicalScores = currentCandidates.map(candidate => {
                const p = this.pronosticos.find(pred => {
                    const pJid = String(pred.jId || pred.jornadaId || '');
                    const pMid = String(pred.mId || pred.memberId || '');
                    return pJid === String(checkJornada.id) && pMid === String(candidate.id);
                });

                let points = -5;
                if (p && p.selection) {
                    const isLate = p.late && !p.pardoned;
                    if (isLate) {
                        points = ScoringSystem.calculateScore(0, jDate);
                    } else {
                        const ev = ScoringSystem.evaluateForecast(p.selection, officialResults, jDate);
                        points = ev.points;
                    }
                }

                return { id: candidate.id, name: candidate.name, points: points };
            });

            // Encontrar el máximo de puntos en esta jornada histórica
            const maxHistoricalPoints = Math.max(...historicalScores.map(s => s.points));
            const survivors = historicalScores.filter(s => s.points === maxHistoricalPoints);

            console.log(`DOUBLES: Desempate en J${checkJornadaNum} - Max puntos: ${maxHistoricalPoints}, Supervivientes:`, survivors.map(s => s.name));

            // Filtrar candidatos que sobreviven
            currentCandidates = currentCandidates.filter(c =>
                survivors.some(s => s.id === c.id)
            );

            checkJornadaNum--;
        }

        return currentCandidates;
    }

    renderDoublesForm(jornada, isLocked) {
        this.doublesContainer.innerHTML = '';
        this.doublesStatus.textContent = '';
        this.doublesStatus.className = '';
        this.btnSaveDoubles.style.display = isLocked ? 'none' : 'block';

        // Load existing doubles
        const existingExtra = this.pronosticosExtra.find(p => (p.jId == this.currentJornadaId || p.jornadaId == this.currentJornadaId) && (p.mId == this.currentMemberId || p.memberId == this.currentMemberId));
        const selections = existingExtra ? existingExtra.selection : Array(15).fill('');

        jornada.matches.forEach((match, idx) => {
            const displayIdx = idx === 14 ? 'P15' : idx + 1;
            const row = document.createElement('div');
            row.className = 'pronostico-row doubles-row';

            const homeLogo = AppUtils.getTeamLogo(match.home);
            const awayLogo = AppUtils.getTeamLogo(match.away);

            const isP15 = idx === 14;

            row.innerHTML = `
                <div class="p-match-info">
                    <div class="match-team home-team">
                        <span class="match-display-idx" style="font-weight:bold; color:var(--primary-green); font-size: 0.8rem; width: 22px;">${displayIdx}</span>
                        <div class="team-info-stacked">
                            <div class="team-line">
                                <img src="${homeLogo}" class="team-logo" style="width:16px; height:16px; object-fit:contain;" onerror="this.style.display='none'">
                                <span class="team-name" style="font-size:0.8rem;">${match.home}</span>
                            </div>
                            <div class="team-line">
                                <img src="${awayLogo}" class="team-logo" style="width:16px; height:16px; object-fit:contain;" onerror="this.style.display='none'">
                                <span class="team-name" style="font-size:0.8rem;">${match.away}</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="prediction-inputs" data-idx="${idx}">
                    ${isP15 ? this.renderP15Inputs(idx, selections[idx], isLocked) : this.renderMultiSelectButtons(idx, selections[idx], isLocked)}
                </div>
            `;
            this.doublesContainer.appendChild(row);

            // Add Block Dividers: 4, 4, 3, 3 + Pleno al 15
            // 4-5 (idx 3), 8-9 (idx 7), 11-12 (idx 10), 14-15 (idx 13)
            if ([3, 7, 10, 13].includes(idx)) {
                const divider = document.createElement('div');
                if (idx === 13) {
                    divider.className = "p-divider p-divider-p15";
                    divider.innerHTML = `<span class="boleto-block-label">PLENO AL 15</span>`;
                } else {
                    divider.className = "p-divider p-divider-block";
                }
                this.doublesContainer.appendChild(divider);
            }
        });

        this.updateDoublesCounters();
    }

    renderMultiSelectButtons(idx, currentVal, disabled, isP15) {
        // currentVal is string "1", "1X", "1X2", etc.
        const options = ['1', 'X', '2'];
        let html = '';
        options.forEach(opt => {
            const isSelected = currentVal && currentVal.includes(opt);
            // Use same styles as chk-option but slightly smaller for side panel
            const activeStyle = isSelected ? 'background-color:var(--primary-green); color:white; border-color:var(--primary-green);' : '';

            html += `<div class="chk-option ${isSelected ? 'selected' : ''}"
            style="width:30px; height:30px; font-size:0.9rem; ${activeStyle}"
            onclick="window.app.handleDoubleToggle(this, ${idx}, '${opt}', ${isP15})" 
                        ${disabled ? 'disabled' : ''}>${opt}</div>`;
        });
        return html;
    }

    renderP15Inputs(idx, currentVal, disabled) {
        // currentVal is usually "HomeGoals-AwayGoals" e.g "M-1"
        const [hVal, aVal] = currentVal ? currentVal.split('-') : ['', ''];
        const options = ['0', '1', '2', 'M'];

        const renderGroup = (team, selected) => {
            let html = `<div class="p15-options-group">`;
            options.forEach(opt => {
                const isSel = opt === selected;
                html += `<div class="p15-option ${isSel ? 'selected' : ''}"
            data-team="${team}" data-val="${opt}"
            onclick="window.app.handleP15Toggle(this, ${idx}, '${team}', '${opt}')" 
                        ${disabled ? 'disabled' : ''}>${opt}</div>`;
            });
            html += `</div>`;
            return html;
        };

        return `<div class="p15-grid">
                ${renderGroup('home', hVal)}
                    ${renderGroup('away', aVal)}
                </div>`;
    }

    handleP15Toggle(btn, idx, team, val) {
        // Find parent container for this team
        const wrapper = btn.parentElement;
        const all = wrapper.querySelectorAll('.p15-option');
        all.forEach(b => {
            b.classList.remove('selected');
            b.style.backgroundColor = '';
            b.style.color = '';
            b.style.borderColor = '#ccc';
        });

        btn.classList.add('selected');
        btn.style.backgroundColor = 'var(--primary-orange)';
        btn.style.color = 'white';
        btn.style.borderColor = 'var(--primary-orange)';
    }

    handleDoubleToggle(btn, idx, sign, isP15) {
        const parent = btn.parentElement;
        const allBtns = parent.querySelectorAll('.chk-option');

        if (isP15) {
            // Single Select behavior for P15
            // Single Select behavior for P15
            allBtns.forEach(b => {
                b.classList.remove('selected');
                b.style.backgroundColor = '';
                b.style.color = '';
                b.style.borderColor = '';
            });
            btn.classList.add('selected');
            btn.style.backgroundColor = 'var(--primary-green)';
            btn.style.color = 'white';
            btn.style.borderColor = 'var(--primary-green)';
        } else {
            // Toggle
            if (btn.classList.contains('selected')) {
                btn.classList.remove('selected');
                btn.style.backgroundColor = '';
                btn.style.color = '';
                btn.style.borderColor = '';
            } else {
                btn.classList.add('selected');
                btn.style.backgroundColor = 'var(--primary-green)';
                btn.style.color = 'white';
                btn.style.borderColor = 'var(--primary-green)';
            }
        }
        this.updateDoublesCounters();
    }

    updateDoublesCounters() {
        // Scan all inputs
        let doubles = 0;
        let triples = 0;

        const rows = this.doublesContainer.querySelectorAll('.prediction-inputs');
        rows.forEach(row => {
            const idx = parseInt(row.dataset.idx);
            if (idx === 14) return; // Skip P15 for count (usually P15 doesn't count for reduction cost)

            const active = row.querySelectorAll('.chk-option.selected').length;
            if (active === 2) doubles++;
            if (active === 3) triples++;
        });

        // Rules: Exactly 7 Doubles OR Exactly 4 Doubles (no triples)
        const isValid = (doubles === 7 && triples === 0) || (doubles === 4 && triples === 0);

        this.doublesCounter.textContent = `${doubles} Dobles, ${triples} Triples`;

        if (!isValid) {
            this.doublesCounter.style.color = '#ff5252'; // Red
            this.doublesCounter.style.backgroundColor = '#ffebee';
            this.doublesCounter.style.border = "1px solid red";
            this.doublesCounter.innerHTML += '<br><span style="font-size:0.7rem;">(Error: Deben ser EXACTAMENTE 7 Dobles o 4 Dobles)</span>';
        } else {
            this.doublesCounter.style.color = '#ffeb3b'; // Yellow
            this.doublesCounter.style.backgroundColor = 'rgba(0,0,0,0.2)';
            this.doublesCounter.style.border = "none";
        }
        return isValid;
    }

    async saveDoubles() {
        const jornada = this.jornadas.find(j => j.id == this.currentJornadaId);
        if (jornada) {
            const { isLockedRef, hasStarted } = this.isJornadaLocked(jornada);
            if (isLockedRef && !this.correctionMode) {
                if (hasStarted) {
                    alert("No se puede guardar la quiniela de dobles: la jornada ya cuenta con resultados registrados.");
                } else {
                    alert("Esta jornada está bloqueada y no admite cambios en la quiniela de dobles sin activar el Modo Corrección.");
                }
                return;
            }
        }

        if (!this.updateDoublesCounters()) {
            alert('La combinación no es válida. \n\nPara poder guardar, debes seleccionar EXACTAMENTE:\n- 7 Dobles (y 0 Triples)\nO bien\n- 4 Dobles (y 0 Triples)');
            return;
        }

        const rows = this.doublesContainer.querySelectorAll('.prediction-inputs');
        const selection = [];
        let missing = false;

        rows.forEach((row, idx) => {
            if (idx === 14) {
                // P15 Logic
                const homeMsg = row.querySelector('.p15-option[data-team="home"].selected');
                const awayMsg = row.querySelector('.p15-option[data-team="away"].selected');

                if (!homeMsg || !awayMsg) {
                    missing = true;
                    selection.push('');
                } else {
                    selection.push(`${homeMsg.dataset.val}-${awayMsg.dataset.val}`);
                }
            } else {
                const btns = row.querySelectorAll('.chk-option.selected');
                if (btns.length === 0) missing = true;

                // Build string "1X", "2", "1X2"
                let val = '';
                // Assuming order 0=1, 1=X, 2=2
                const optionDivs = row.querySelectorAll('.chk-option');
                if (optionDivs[0].classList.contains('selected')) val += '1';
                if (optionDivs[1].classList.contains('selected')) val += 'X';
                if (optionDivs[2].classList.contains('selected')) val += '2';
                selection.push(val);
            }
        });

        if (missing) {
            alert('Debes rellenar todos los signos (incluido el Pleno al 15).');
            return;
        }

        const doubles = selection.filter((s, i) => i < 14 && s.length === 2).length;
        const isReduced = (doubles === 7);

        const data = {
            id: `${this.currentJornadaId}_${this.currentMemberId}`,
            jId: this.currentJornadaId,
            mId: this.currentMemberId,
            selection: selection,
            isReduced: isReduced,
            date: new Date().toISOString()
        };

        try {
            this.btnSaveDoubles.disabled = true;
            this.btnSaveDoubles.textContent = 'Guardando...';

            await window.DataService.save('pronosticos_extra', data);

            // Update in-memory state
            const existingIdx = this.pronosticosExtra.findIndex(p => p.id === data.id);
            if (existingIdx >= 0) this.pronosticosExtra[existingIdx] = data;
            else this.pronosticosExtra.push(data);

            this.doublesStatus.textContent = '✅ Quiniela de dobles guardada correctamente.';
            this.doublesStatus.className = 'success-message';
            this.btnSaveDoubles.textContent = '✅ ¡Guardado con Éxito!';
            this.btnSaveDoubles.style.backgroundColor = '#4caf50';

            // Refresh summary table to show the new/updated doubles row
            this.renderSummaryTable();

            setTimeout(() => {
                this.btnSaveDoubles.style.backgroundColor = '';
                this.btnSaveDoubles.textContent = '💾 Guardar Quiniela de Dobles';
                this.btnSaveDoubles.disabled = false;
            }, 3000);

        } catch (e) {
            console.error(e);
            alert('Error al guardar: ' + e.message);
            this.btnSaveDoubles.textContent = '💾 Guardar Quiniela de Dobles';
            this.btnSaveDoubles.disabled = false;
        }
    }
    handleCopyForecast() {
        const jornada = this.jornadas.find(j => j.id == this.currentJornadaId);
        if (jornada) {
            const { isLockedRef, hasStarted } = this.isJornadaLocked(jornada);
            if (isLockedRef && !this.correctionMode) {
                if (hasStarted) {
                    alert("No se puede copiar el pronóstico: la jornada ya cuenta con resultados registrados.");
                } else {
                    alert("Esta jornada está bloqueada y no admite cambios sin activar el Modo Corrección.");
                }
                return;
            }
        }

        // 1. Get Normal Forecast
        const normalRows = this.container.querySelectorAll('.p-options');
        const normalSelections = [];
        let hasData = false;

        normalRows.forEach(row => {
            const selected = row.querySelector('.selected');
            if (selected) {
                normalSelections.push(selected.textContent.trim());
                hasData = true;
            } else {
                normalSelections.push('');
            }
        });

        if (!hasData) {
            alert("No hay pronóstico base seleccionado para copiar.");
            return;
        }

        // 2. Check Doubles Target
        const doublesRows = this.doublesContainer.querySelectorAll('.prediction-inputs');
        let hasExistingDoubles = false;
        doublesRows.forEach(row => {
            if (row.querySelectorAll('.chk-option.selected').length > 0) hasExistingDoubles = true;
        });

        if (hasExistingDoubles) {
            if (!confirm("⚠️ ¡ATENCIÓN!\n\nSe sobrescribirá tu quiniela de dobles actual con los datos del pronóstico base.\n\n¿Estás seguro de continuar?")) {
                return;
            }
        }

        // 3. Apply Copy
        doublesRows.forEach((row, idx) => {
            const val = normalSelections[idx];

            // Clear current row
            const options = row.querySelectorAll('.chk-option');
            options.forEach(opt => {
                opt.classList.remove('selected');
                opt.style.backgroundColor = '';
                opt.style.color = '';
                opt.style.borderColor = '';
            });

            if (val) {
                // Find correct button and click/activate it
                const targetBtn = Array.from(options).find(opt => opt.textContent.trim() === val);
                if (targetBtn) {
                    targetBtn.classList.add('selected');
                    targetBtn.style.backgroundColor = 'var(--primary-green)';
                    targetBtn.style.color = 'white';
                    targetBtn.style.borderColor = 'var(--primary-green)';
                }
            }
        });

        this.updateDoublesCounters();
        this.doublesStatus.innerHTML = '<span style="color:blue;">✅ Copiado desde base. Revisa y guarda.</span>';
    }

    calculatePerfectColumn(currentJornada) {
        // To build the perfect column, we need to analyze historical performance per match index
        const memberPerformancePerMatch = {}; // { memberId: [hits_at_idx_0, hits_at_idx_1, ...] }
        const currentClassification = [...this.members].map(m => {
            const forecasts = this.pronosticos.filter(p => String(p.mId || p.memberId) === String(m.id));
            let totalPoints = 0;
            forecasts.forEach(p => {
                const j = this.jornadas.find(jor => String(jor.id) === String(p.jId || p.jornadaId));
                if (j && j.matches) {
                    const results = j.matches.map(mt => mt.result);
                    if (results.some(r => r)) {
                        const ev = ScoringSystem.evaluateForecast(p.selection || [], results);
                        totalPoints += ev.points;
                    }
                }
            });
            return { id: m.id, points: totalPoints };
        }).sort((a, b) => b.points - a.points);

        // 1. Calculate how many times each member hit each match index
        this.members.forEach(m => {
            memberPerformancePerMatch[m.id] = Array(15).fill(0);
            const mForecasts = this.pronosticos.filter(p => String(p.mId || p.memberId) === String(m.id));

            mForecasts.forEach(p => {
                const j = this.jornadas.find(jor => String(jor.id) === String(p.jId || p.jornadaId));
                if (j && j.matches) {
                    const results = j.matches.map(mt => mt.result);
                    if (results.some(r => r)) {
                        (p.selection || []).forEach((sel, idx) => {
                            if (sel && sel === results[idx]) memberPerformancePerMatch[m.id][idx]++;
                        });
                    }
                }
            });
        });

        const perfectCol = [];
        const currentJForecasts = this.pronosticos.filter(p => String(p.jId || p.jornadaId) === String(currentJornada.id));

        for (let i = 0; i < 15; i++) {
            // Find member(s) with max historical hits for this specific match index i
            let maxHits = -1;
            let expertIds = [];
            this.members.forEach(m => {
                const hits = memberPerformancePerMatch[m.id][i];
                if (hits > maxHits) {
                    maxHits = hits;
                    expertIds = [m.id];
                } else if (hits === maxHits && hits > 0) {
                    expertIds.push(m.id);
                }
            });

            const currentSignFrequency = {}; // Sign -> count of experts choosing it
            expertIds.forEach(eid => {
                const p = currentJForecasts.find(f => String(f.mId || f.memberId) === String(eid));
                if (p && p.selection && p.selection[i]) {
                    const s = p.selection[i];
                    currentSignFrequency[s] = (currentSignFrequency[s] || 0) + 1;
                }
            });

            const signs = Object.keys(currentSignFrequency);
            if (signs.length === 0) {
                perfectCol.push('-');
                continue;
            }

            // Find sign(s) with max frequency among experts
            let maxFreq = -1;
            let topSigns = [];
            signs.forEach(s => {
                if (currentSignFrequency[s] > maxFreq) {
                    maxFreq = currentSignFrequency[s];
                    topSigns = [s];
                } else if (currentSignFrequency[s] === maxFreq) {
                    topSigns.push(s);
                }
            });

            if (topSigns.length === 1) {
                perfectCol.push(topSigns[0]);
            } else {
                // Tie-break: Sign chosen by the best-ranked member among those who chose a topSign
                let finalSign = topSigns[0];

                for (const rank of currentClassification) {
                    const p = currentJForecasts.find(f => String(f.mId || f.memberId) === String(rank.id));
                    if (p && p.selection && p.selection[i] && topSigns.includes(p.selection[i])) {
                        finalSign = p.selection[i];
                        break;
                    }
                }
                perfectCol.push(finalSign);
            }
        }

        return perfectCol;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.app = new PronosticoManager();
});
